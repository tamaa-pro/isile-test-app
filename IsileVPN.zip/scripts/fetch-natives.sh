#!/usr/bin/env bash
# يجلب/يبني المكونات الأصلية ويضعها في jniLibs (arm64-v8a)
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
OUT="$ROOT/app/src/main/jniLibs/arm64-v8a"
TMP="$(mktemp -d)"
mkdir -p "$OUT"

echo "==> [1/3] Xray-core (VLESS / VMess / Trojan)"
curl -fL "https://github.com/XTLS/Xray-core/releases/latest/download/Xray-android-arm64-v8a.zip" -o "$TMP/xray.zip"
mkdir -p "$TMP/xray" && unzip -o "$TMP/xray.zip" xray -d "$TMP/xray"
cp "$TMP/xray/xray" "$OUT/libxray.so"
chmod +x "$OUT/libxray.so"

echo "==> [2/3] hev-socks5-tunnel (TUN -> SOCKS5)"
NDK="${ANDROID_NDK_LATEST_HOME:-${ANDROID_NDK_HOME:-${ANDROID_NDK_ROOT:-}}}"
if [ -z "$NDK" ] || [ ! -x "$NDK/ndk-build" ]; then
  NDK="$(ls -d "${ANDROID_HOME:-${ANDROID_SDK_ROOT:-/usr/local/lib/android/sdk}}"/ndk/* 2>/dev/null | sort -V | tail -n1)"
fi
echo "NDK: $NDK"
T="$TMP/tproxy"
mkdir -p "$T/jni"
echo 'include $(call all-subdir-makefiles)' > "$T/jni/Android.mk"
git clone --recursive --depth 1 https://github.com/heiher/hev-socks5-tunnel "$T/jni/hev-socks5-tunnel"
"$NDK/ndk-build" NDK_PROJECT_PATH="$T" APP_BUILD_SCRIPT="$T/jni/Android.mk" \
  APP_ABI=arm64-v8a APP_PLATFORM=android-24 NDK_LIBS_OUT="$T/libs" NDK_OUT="$T/obj"
cp "$T/libs/arm64-v8a/libhev-socks5-tunnel.so" "$OUT/"

echo "==> [3/3] dnstt-client (SlowDNS) - اختياري"
if git clone --depth 1 https://www.bamsoftware.com/git/dnstt.git "$TMP/dnstt"; then
  ( cd "$TMP/dnstt/dnstt-client" && CGO_ENABLED=0 GOOS=linux GOARCH=arm64 \
      go build -ldflags "-s -w" -o "$OUT/libdnstt.so" . ) \
    || echo "WARN: dnstt build failed - SlowDNS will be unavailable"
else
  echo "WARN: could not clone dnstt - SlowDNS will be unavailable"
fi

ls -lh "$OUT"
