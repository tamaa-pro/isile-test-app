package hev.htproxy;

/**
 * JNI bridge expected by libhev-socks5-tunnel.so (class name must not change).
 * Signatures follow hev-socks5-tunnel >= 2.17.0 (Start/Stop return boolean, IsRunning added).
 * A mismatch makes JNI_OnLoad fail with "JNI_ERR returned from JNI_OnLoad".
 */
public class TProxyService {
    static {
        System.loadLibrary("hev-socks5-tunnel");
    }

    public static native boolean TProxyStartService(String configPath, int fd);

    public static native boolean TProxyStopService();

    public static native boolean TProxyIsRunning();

    public static native long[] TProxyGetStats();
}
