package hev.htproxy;

/** JNI bridge expected by libhev-socks5-tunnel.so (class name must not change). */
public class TProxyService {
    static {
        System.loadLibrary("hev-socks5-tunnel");
    }

    public static native void TProxyStartService(String configPath, int fd);

    public static native void TProxyStopService();

    public static native long[] TProxyGetStats();
}
