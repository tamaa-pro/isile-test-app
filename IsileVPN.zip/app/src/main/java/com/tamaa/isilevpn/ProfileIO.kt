package com.tamaa.isilevpn

import android.net.Uri
import android.util.Base64
import org.json.JSONObject
import java.security.MessageDigest
import java.security.SecureRandom
import javax.crypto.Cipher
import javax.crypto.spec.GCMParameterSpec
import javax.crypto.spec.SecretKeySpec

/** يبني رابطًا قابلاً للمشاركة من أي كونفيج (ssh / vless / vmess / trojan). */
object LinkGen {
    fun make(p: Profile): String = when (p.kind) {
        Kind.SSH -> ssh(p)
        Kind.VMESS -> vmess(p)
        Kind.VLESS -> uri(p, "vless")
        Kind.TROJAN -> uri(p, "trojan")
    }

    private fun hostPart(h: String) = if (h.contains(':') && !h.startsWith("[")) "[$h]" else h

    private fun build(scheme: String, info: String, p: Profile, q: List<Pair<String, String>>): String {
        val sb = StringBuilder("$scheme://").append(info).append('@').append(hostPart(p.host)).append(':').append(p.port)
        if (q.isNotEmpty()) sb.append('?').append(q.joinToString("&") { "${it.first}=${Uri.encode(it.second)}" })
        if (p.name.isNotBlank()) sb.append('#').append(Uri.encode(p.name))
        return sb.toString()
    }

    private fun ssh(p: Profile): String {
        val q = ArrayList<Pair<String, String>>()
        if (p.payloadOn) q += "payload" to p.payload
        if (p.proxyHost.isNotBlank()) q += "proxy" to "${p.proxyHost.trim()}:${p.proxyPort}"
        if (p.ws) {
            q += "ws" to "1"
            if (p.wsPath.isNotEmpty() && p.wsPath != "/") q += "path" to p.wsPath
            if (p.wsHost.isNotEmpty()) q += "host" to p.wsHost
        }
        if (p.tls) {
            q += "tls" to "1"
            if (p.sni.isNotEmpty()) q += "sni" to p.sni
            if (p.tlsVersion.isNotEmpty() && p.tlsVersion != "Auto") q += "tlsv" to p.tlsVersion
            if (p.insecure) q += "insecure" to "1"
        }
        return build("ssh", Uri.encode(p.user) + ":" + Uri.encode(p.pass), p, q)
    }

    private fun net(p: Profile) = if (p.ws) "ws" else when (p.network) {
        "grpc", "httpupgrade", "xhttp" -> p.network
        else -> "tcp"
    }

    private fun uri(p: Profile, scheme: String): String {
        val n = net(p)
        val q = ArrayList<Pair<String, String>>()
        if (p.kind == Kind.VLESS) q += "encryption" to p.encryption.ifEmpty { "none" }
        if (p.flow.isNotEmpty()) q += "flow" to p.flow
        val sec = if (!p.tls) "none" else if (p.security == "reality") "reality" else "tls"
        q += "security" to sec
        q += "type" to n
        when (n) {
            "ws", "httpupgrade", "xhttp" -> {
                q += "path" to p.wsPath.ifEmpty { "/" }
                if (p.wsHost.isNotEmpty()) q += "host" to p.wsHost
            }
            "grpc" -> q += "serviceName" to p.serviceName
        }
        if (p.tls) {
            if (p.sni.isNotEmpty()) q += "sni" to p.sni
            if (p.fingerprint.isNotEmpty()) q += "fp" to p.fingerprint
            if (p.alpn.isNotEmpty()) q += "alpn" to p.alpn
            if (sec == "reality") {
                if (p.pbk.isNotEmpty()) q += "pbk" to p.pbk
                if (p.sid.isNotEmpty()) q += "sid" to p.sid
                if (p.spx.isNotEmpty()) q += "spx" to p.spx
            }
            if (p.insecure) q += "allowInsecure" to "1"
        }
        return build(scheme, Uri.encode(p.secret), p, q)
    }

    private fun vmess(p: Profile): String {
        val n = net(p)
        val j = JSONObject()
            .put("v", "2").put("ps", p.name).put("add", p.host).put("port", p.port.toString())
            .put("id", p.secret).put("aid", p.alterId.toString()).put("scy", p.vmessScy.ifEmpty { "auto" })
            .put("net", n).put("type", "none")
            .put("host", p.wsHost)
            .put("path", if (n == "grpc") p.serviceName else p.wsPath.ifEmpty { "/" })
            .put("tls", if (p.tls) "tls" else "")
            .put("sni", p.sni).put("alpn", p.alpn).put("fp", p.fingerprint)
        if (p.insecure) j.put("allowInsecure", "1")
        return "vmess://" + Base64.encodeToString(j.toString().toByteArray(), Base64.NO_WRAP)
    }
}

/**
 * ملف .isl: كونفيج مشفّر (AES-256-GCM). علامة الإغلاق (locked) داخل الجزء المشفّر
 * فلا يمكن تغييرها بتعديل الملف.
 */
object IslFile {
    const val EXT = "isl"
    const val MIME = "application/octet-stream"
    private val MAGIC = byteArrayOf('I'.code.toByte(), 'S'.code.toByte(), 'L'.code.toByte(), '1'.code.toByte())
    private val key by lazy {
        SecretKeySpec(MessageDigest.getInstance("SHA-256").digest("IsileVPN/isl/v1/6f1c9a".toByteArray()), "AES")
    }

    fun encode(p: Profile, locked: Boolean): ByteArray {
        val j = p.toJson()
        j.remove("uid")
        j.put("locked", locked)
        val iv = ByteArray(12).also { SecureRandom().nextBytes(it) }
        val c = Cipher.getInstance("AES/GCM/NoPadding")
        c.init(Cipher.ENCRYPT_MODE, key, GCMParameterSpec(128, iv))
        return MAGIC + iv + c.doFinal(j.toString().toByteArray())
    }

    fun decode(b: ByteArray): Profile {
        if (b.size < 4 + 12 + 16 || !b.copyOfRange(0, 4).contentEquals(MAGIC))
            throw IllegalArgumentException("Not a valid .isl file")
        try {
            val c = Cipher.getInstance("AES/GCM/NoPadding")
            c.init(Cipher.DECRYPT_MODE, key, GCMParameterSpec(128, b.copyOfRange(4, 16)))
            val j = JSONObject(String(c.doFinal(b, 16, b.size - 16)))
            return Profile.fromJson(j).also { it.uid = java.util.UUID.randomUUID().toString() }
        } catch (e: Exception) {
            throw IllegalArgumentException("Corrupted or unsupported .isl file")
        }
    }
}
