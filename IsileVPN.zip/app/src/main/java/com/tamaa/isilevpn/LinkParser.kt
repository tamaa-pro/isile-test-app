package com.tamaa.isilevpn

import android.net.Uri
import android.util.Base64
import org.json.JSONObject

/** يحوّل روابط vless:// vmess:// trojan:// إلى Profile جاهز لملء الخانات. */
object LinkParser {
    fun parse(raw: String): Profile {
        val l = raw.trim()
        return when {
            l.startsWith("vless://", true) -> fromUri(l, Kind.VLESS)
            l.startsWith("trojan://", true) -> fromUri(l, Kind.TROJAN)
            l.startsWith("vmess://", true) -> fromVmess(l)
            l.startsWith("ssh://", true) -> fromSsh(l)
            else -> fromPlainSsh(l)
        }
    }

    private fun net(t: String?): String = when (t) {
        "ws", "grpc", "httpupgrade", "xhttp" -> t
        "splithttp" -> "xhttp"
        else -> "tcp"
    }

    private fun truthy(v: String?) = v == "1" || v.equals("true", true)

    private fun fromUri(l: String, kind: Kind): Profile {
        val u = Uri.parse(l)
        val q = HashMap<String, String>()
        for (k in u.queryParameterNames) u.getQueryParameter(k)?.let { q[k] = it }
        val p = Profile(kind = kind)
        p.host = u.host ?: throw IllegalArgumentException("Missing host")
        p.port = if (u.port > 0) u.port else 443
        p.secret = u.userInfo ?: throw IllegalArgumentException("Missing UUID / password")
        p.name = u.fragment.orEmpty()
        p.network = net(q["type"])
        p.ws = p.network == "ws"
        p.wsPath = q["path"]?.ifEmpty { null } ?: "/"
        p.wsHost = q["host"].orEmpty()
        p.serviceName = q["serviceName"].orEmpty()
        val sec = q["security"]?.ifEmpty { null } ?: if (kind == Kind.TROJAN) "tls" else "none"
        p.security = sec
        p.tls = sec == "tls" || sec == "reality"
        p.sni = (q["sni"] ?: q["peer"]).orEmpty()
        p.fingerprint = q["fp"] ?: "chrome"
        p.alpn = q["alpn"].orEmpty()
        p.insecure = truthy(q["allowInsecure"]) || truthy(q["insecure"])
        p.flow = q["flow"].orEmpty()
        p.encryption = q["encryption"]?.ifEmpty { null } ?: "none"
        p.pbk = q["pbk"].orEmpty()
        p.sid = q["sid"].orEmpty()
        p.spx = q["spx"].orEmpty()
        return p
    }

    private fun fromVmess(l: String): Profile {
        var b64 = l.substring(8).substringBefore('#').trim()
        b64 = b64.replace('-', '+').replace('_', '/')
        val j = try {
            JSONObject(String(Base64.decode(b64, Base64.DEFAULT)))
        } catch (e: Exception) {
            throw IllegalArgumentException("Invalid vmess link")
        }
        val p = Profile(kind = Kind.VMESS)
        p.name = j.optString("ps")
        p.host = j.optString("add").ifEmpty { throw IllegalArgumentException("Missing host") }
        p.port = j.optString("port", "443").toIntOrNull() ?: 443
        p.secret = j.optString("id").ifEmpty { throw IllegalArgumentException("Missing UUID") }
        p.alterId = j.optString("aid", "0").toIntOrNull() ?: 0
        p.vmessScy = j.optString("scy").ifEmpty { "auto" }
        p.network = net(j.optString("net", "tcp"))
        p.ws = p.network == "ws"
        p.wsPath = j.optString("path").ifEmpty { "/" }
        p.serviceName = j.optString("path")
        p.wsHost = j.optString("host")
        p.tls = j.optString("tls") == "tls"
        p.security = if (p.tls) "tls" else "none"
        p.sni = j.optString("sni")
        p.fingerprint = j.optString("fp").ifEmpty { "chrome" }
        p.alpn = j.optString("alpn")
        p.insecure = truthy(j.optString("allowInsecure"))
        return p
    }

    // ---------- SSH ----------
    private fun queryMap(q: String): Map<String, String> {
        val m = HashMap<String, String>()
        for (kv in q.split('&')) {
            if (kv.isEmpty()) continue
            val k = kv.substringBefore('=')
            m[Uri.decode(k)] = Uri.decode(kv.substringAfter('=', ""))
        }
        return m
    }

    private fun splitHostPort(hp: String, defPort: Int): Pair<String, Int> {
        val h = hp.trim()
        if (h.startsWith("[")) {
            val end = h.indexOf(']')
            if (end > 0) return h.substring(1, end) to (h.substring(end + 1).removePrefix(":").toIntOrNull() ?: defPort)
        }
        val i = h.lastIndexOf(':')
        if (i > 0 && h.count { it == ':' } == 1) {
            val port = h.substring(i + 1).toIntOrNull()
            if (port != null) return h.substring(0, i) to port
        }
        return h to defPort
    }

    /** ssh://user:pass@host:port?payload=..&proxy=host:port&ws=1&tls=1&sni=..&tlsv=..&insecure=1#name */
    private fun fromSsh(l: String): Profile {
        val body = l.substring(6)
        val name = Uri.decode(body.substringAfter('#', ""))
        val noFrag = body.substringBefore('#')
        val q = queryMap(noFrag.substringAfter('?', ""))
        val main = noFrag.substringBefore('?').trimEnd('/')
        val at = main.lastIndexOf('@')
        if (at < 0) throw IllegalArgumentException("Missing user / password")
        val info = main.substring(0, at)
        val (host, port) = splitHostPort(main.substring(at + 1), 22)
        if (host.isEmpty()) throw IllegalArgumentException("Missing host")
        val p = Profile(kind = Kind.SSH)
        p.name = name
        p.host = host; p.port = port
        p.user = Uri.decode(info.substringBefore(':'))
        p.pass = Uri.decode(info.substringAfter(':', ""))
        q["payload"]?.let { p.payloadOn = true; p.payload = it }
        q["proxy"]?.let {
            val (ph, pp) = splitHostPort(it, 8080)
            p.proxyHost = ph; p.proxyPort = pp
        }
        p.ws = truthy(q["ws"])
        q["path"]?.let { p.wsPath = it.ifEmpty { "/" } }
        q["host"]?.let { p.wsHost = it }
        p.tls = truthy(q["tls"])
        p.sni = q["sni"].orEmpty()
        p.tlsVersion = q["tlsv"]?.ifEmpty { null } ?: "Auto"
        p.insecure = truthy(q["insecure"])
        return p
    }

    /** صيغ بسيطة شائعة: host:port@user:pass  أو  host:port:user:pass */
    private fun fromPlainSsh(raw: String): Profile {
        val t = raw.trim().lineSequence().firstOrNull { it.isNotBlank() }?.trim().orEmpty()
        val a = Regex("^([^\\s:@/]+):(\\d{1,5})@([^:\\s]+):(.+)$").find(t)
        val b = Regex("^([^\\s:@/]+):(\\d{1,5}):([^:\\s]+):(.+)$").find(t)
        val m = a ?: b ?: throw IllegalArgumentException("Unrecognized config. Use a link or host:port@user:pass")
        val p = Profile(kind = Kind.SSH)
        p.host = m.groupValues[1]
        p.port = m.groupValues[2].toInt().takeIf { it in 1..65535 } ?: 22
        p.user = m.groupValues[3]
        p.pass = m.groupValues[4]
        return p
    }
}
