package com.tamaa.isilevpn

import android.net.Uri
import android.util.Base64
import org.json.JSONObject

/** يحوّل روابط vless:// vmess:// trojan:// إلى Profile جاهز لملء الخانات. */
object LinkParser {
    fun parse(raw: String): Profile {
        val l = raw.trim()
        return when {
            l.startsWith("vless://", true) -> fromUri(l, Kind.VLESS)
            l.startsWith("trojan://", true) -> fromUri(l, Kind.TROJAN)
            l.startsWith("vmess://", true) -> fromVmess(l)
            else -> throw IllegalArgumentException("Not a vless / vmess / trojan link")
        }
    }

    private fun net(t: String?): String = when (t) {
        "ws", "grpc", "httpupgrade", "xhttp" -> t
        "splithttp" -> "xhttp"
        else -> "tcp"
    }

    private fun truthy(v: String?) = v == "1" || v.equals("true", true)

    private fun fromUri(l: String, kind: Kind): Profile {
        val u = Uri.parse(l)
        val q = HashMap<String, String>()
        for (k in u.queryParameterNames) u.getQueryParameter(k)?.let { q[k] = it }
        val p = Profile(kind = kind)
        p.host = u.host ?: throw IllegalArgumentException("Missing host")
        p.port = if (u.port > 0) u.port else 443
        p.secret = u.userInfo ?: throw IllegalArgumentException("Missing UUID / password")
        p.name = u.fragment.orEmpty()
        p.network = net(q["type"])
        p.ws = p.network == "ws"
        p.wsPath = q["path"]?.ifEmpty { null } ?: "/"
        p.wsHost = q["host"].orEmpty()
        p.serviceName = q["serviceName"].orEmpty()
        val sec = q["security"]?.ifEmpty { null } ?: if (kind == Kind.TROJAN) "tls" else "none"
        p.security = sec
        p.tls = sec == "tls" || sec == "reality"
        p.sni = (q["sni"] ?: q["peer"]).orEmpty()
        p.fingerprint = q["fp"] ?: "chrome"
        p.alpn = q["alpn"].orEmpty()
        p.insecure = truthy(q["allowInsecure"]) || truthy(q["insecure"])
        p.flow = q["flow"].orEmpty()
        p.encryption = q["encryption"]?.ifEmpty { null } ?: "none"
        p.pbk = q["pbk"].orEmpty()
        p.sid = q["sid"].orEmpty()
        p.spx = q["spx"].orEmpty()
        return p
    }

    private fun fromVmess(l: String): Profile {
        var b64 = l.substring(8).substringBefore('#').trim()
        b64 = b64.replace('-', '+').replace('_', '/')
        val j = try {
            JSONObject(String(Base64.decode(b64, Base64.DEFAULT)))
        } catch (e: Exception) {
            throw IllegalArgumentException("Invalid vmess link")
        }
        val p = Profile(kind = Kind.VMESS)
        p.name = j.optString("ps")
        p.host = j.optString("add").ifEmpty { throw IllegalArgumentException("Missing host") }
        p.port = j.optString("port", "443").toIntOrNull() ?: 443
        p.secret = j.optString("id").ifEmpty { throw IllegalArgumentException("Missing UUID") }
        p.alterId = j.optString("aid", "0").toIntOrNull() ?: 0
        p.vmessScy = j.optString("scy").ifEmpty { "auto" }
        p.network = net(j.optString("net", "tcp"))
        p.ws = p.network == "ws"
        p.wsPath = j.optString("path").ifEmpty { "/" }
        p.serviceName = j.optString("path")
        p.wsHost = j.optString("host")
        p.tls = j.optString("tls") == "tls"
        p.security = if (p.tls) "tls" else "none"
        p.sni = j.optString("sni")
        p.fingerprint = j.optString("fp").ifEmpty { "chrome" }
        p.alpn = j.optString("alpn")
        p.insecure = truthy(j.optString("allowInsecure"))
        return p
    }
}
