package com.tamaa.isilevpn

import android.content.Context
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

enum class State { IDLE, CONNECTING, CONNECTED }

/** حالة وسجل مشتركان بين الخدمة والواجهة (نفس العملية). */
object Bus {
    @Volatile var state = State.IDLE
    @Volatile var listener: (() -> Unit)? = null
    private val sb = StringBuilder()

    @Synchronized
    fun log(s: String) {
        val t = SimpleDateFormat("HH:mm:ss", Locale.US).format(Date())
        sb.append(t).append("  ").append(s).append('\n')
        if (sb.length > 20000) sb.delete(0, sb.length - 15000)
        listener?.invoke()
    }

    @Synchronized
    fun text(): String = sb.toString()

    fun set(s: State) {
        state = s
        listener?.invoke()
    }
}

object Native {
    fun lib(ctx: Context, name: String) = File(ctx.applicationInfo.nativeLibraryDir, "lib$name.so")
}
