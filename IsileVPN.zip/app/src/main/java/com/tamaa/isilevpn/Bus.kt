package com.tamaa.isilevpn

import android.content.Context
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

enum class State { IDLE, CONNECTING, CONNECTED }

/** حالة وسجل وإحصائيات مشتركة بين الخدمة والواجهة (نفس العملية). */
object Bus {
    const val POINTS = 60

    @Volatile var state = State.IDLE
    @Volatile var listener: (() -> Unit)? = null
    @Volatile var ip = ""
    @Volatile var lastError = ""
    @Volatile var curDown = 0L
    @Volatile var curUp = 0L
    @Volatile var logVersion = 0

    private val sb = StringBuilder()
    private val hd = ArrayList<Long>()
    private val hu = ArrayList<Long>()

    @Synchronized
    fun log(s: String) {
        val t = SimpleDateFormat("HH:mm:ss", Locale.US).format(Date())
        sb.append(t).append("  ").append(s).append('\n')
        if (sb.length > 20000) sb.delete(0, sb.length - 15000)
        logVersion++
        if (s.startsWith("ERROR")) lastError = s.removePrefix("ERROR:").trim()
        listener?.invoke()
    }

    @Synchronized
    fun text(): String = sb.toString()

    @Synchronized
    fun clear() {
        sb.setLength(0)
        logVersion++
        listener?.invoke()
    }

    @Synchronized
    fun pushSpeed(down: Long, up: Long) {
        curDown = down; curUp = up
        hd.add(down); hu.add(up)
        while (hd.size > POINTS) hd.removeAt(0)
        while (hu.size > POINTS) hu.removeAt(0)
        listener?.invoke()
    }

    @Synchronized
    fun history(): Pair<LongArray, LongArray> = Pair(hd.toLongArray(), hu.toLongArray())

    @Synchronized
    private fun resetStats() {
        hd.clear(); hu.clear()
        curDown = 0; curUp = 0
        ip = ""
    }

    fun notifyChanged() { listener?.invoke() }

    fun set(s: State) {
        if (s != State.CONNECTED) resetStats()
        if (s == State.CONNECTING) lastError = ""
        state = s
        listener?.invoke()
    }
}

object Native {
    fun lib(ctx: Context, name: String) = File(ctx.applicationInfo.nativeLibraryDir, "lib$name.so")
}
