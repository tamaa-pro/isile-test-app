package com.tamaa.isilevpn

import android.content.Context
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

enum class State { IDLE, CONNECTING, CONNECTED }

/** يُرمى عند إلغاء محاولة اتصال أثناء تنفيذها (ليس خطأً). */
class CancelledException : Exception()

/**
 * حالة وإحصائيات وسجلّان مشتركة بين الخدمة والواجهة:
 *  - سجل الاتصال (log): مراحل الاتصال والأخطاء التي تهم المستخدم.
 *  - سجل التطبيق (app): تفاصيل داخلية (مخرجات xray، أخطاء المكتبات...).
 */
object Bus {
    const val POINTS = 60

    /** يحل محل \n داخل سطر سجل واحد متعدد الأسطر (رسالة الخادم). */
    const val NL = '\u0001'

    @Volatile var state = State.IDLE
    @Volatile var listener: (() -> Unit)? = null
    @Volatile var ip = ""
    @Volatile var realIp = ""
    @Volatile var realIpFetching = false
    @Volatile var lastError = ""
    @Volatile var curDown = 0L
    @Volatile var curUp = 0L
    @Volatile var logVersion = 0

    private val conn = StringBuilder()
    private val app = StringBuilder()
    private val hd = ArrayList<Long>()
    private val hu = ArrayList<Long>()

    /** قيم تُخفى من السجلات (بيانات كونفيج مغلق). */
    @Volatile var mask: List<String> = emptyList()

    private fun masked(raw: String): String {
        var s = raw
        for (m in mask) s = s.replace(m, "•••")
        return s
    }

    private fun append(sb: StringBuilder, raw: String) {
        val s = masked(raw)
        val t = SimpleDateFormat("HH:mm:ss", Locale.US).format(Date())
        sb.append(t).append("  ").append(s).append('\n')
        if (sb.length > 40000) sb.delete(0, sb.length - 30000)
        logVersion++
    }

    /** سطر في سجل الاتصال. */
    @Synchronized
    fun log(s: String) {
        append(conn, s)
        if (s.startsWith("ERROR")) lastError = masked(s).removePrefix("ERROR:").trim()
        listener?.invoke()
    }

    /** سطر في سجل التطبيق (تفاصيل داخلية). */
    @Synchronized
    fun app(s: String) {
        append(app, s)
        listener?.invoke()
    }

    @Synchronized
    fun text(forApp: Boolean = false): String = (if (forApp) app else conn).toString()

    @Synchronized
    fun clear(forApp: Boolean) {
        (if (forApp) app else conn).setLength(0)
        logVersion++
        listener?.invoke()
    }

    @Synchronized
    fun pushSpeed(down: Long, up: Long) {
        curDown = down; curUp = up
        hd.add(down); hu.add(up)
        while (hd.size > POINTS) hd.removeAt(0)
        while (hu.size > POINTS) hu.removeAt(0)
        listener?.invoke()
    }

    @Synchronized
    fun history(): Pair<LongArray, LongArray> = Pair(hd.toLongArray(), hu.toLongArray())

    @Synchronized
    private fun resetStats() {
        hd.clear(); hu.clear()
        curDown = 0; curUp = 0
        ip = ""
    }

    fun notifyChanged() { listener?.invoke() }

    fun set(s: State) {
        if (s != State.CONNECTED) resetStats()
        if (s == State.CONNECTING) lastError = ""
        state = s
        listener?.invoke()
        if (s == State.IDLE || realIp.isEmpty()) fetchRealIp()
    }
}

/**
 * يجلب IP الهاتف الحقيقي مباشرة (التطبيق مستثنى من النفق فيخرج اتصاله دون VPN).
 * يجرّب عدة مصادر بالتوازي (بعضها على عناوين Cloudflare المباشرة) ويأخذ أول نجاح،
 * لأن بعض الشبكات تحجب مواقع بعينها.
 */
private val IP_SOURCES = listOf(
    "https://1.1.1.1/cdn-cgi/trace",
    "https://www.cloudflare.com/cdn-cgi/trace",
    "https://api.ipify.org",
    "https://api64.ipify.org",
    "https://icanhazip.com",
    "https://checkip.amazonaws.com",
    "https://ifconfig.me/ip",
    "https://ipinfo.io/ip"
)
private val IP_REGEX = Regex("^[0-9a-fA-F:.]{7,45}$")

private fun readIp(url: String): String {
    val c = java.net.URL(url).openConnection() as java.net.HttpURLConnection
    c.connectTimeout = 6000; c.readTimeout = 6000
    c.setRequestProperty("User-Agent", "curl/8.0")
    try {
        if (c.responseCode != 200) throw java.io.IOException("HTTP ${c.responseCode}")
        val body = c.inputStream.bufferedReader().readText().trim()
        val v = body.lineSequence().firstOrNull { it.startsWith("ip=") }?.removePrefix("ip=")?.trim() ?: body
        if (!IP_REGEX.matches(v)) throw java.io.IOException("unexpected reply")
        return v
    } finally { c.disconnect() }
}

fun fetchRealIp() {
    if (Bus.realIpFetching) return
    Bus.realIpFetching = true
    Thread {
        try {
            for (round in 0 until 3) {
                val done = java.util.concurrent.atomic.AtomicBoolean(false)
                val lastErr = java.util.concurrent.atomic.AtomicReference("")
                val ths = IP_SOURCES.map { u ->
                    Thread {
                        try {
                            val ip = readIp(u)
                            if (done.compareAndSet(false, true)) {
                                Bus.realIp = ip
                                Bus.notifyChanged()
                            }
                        } catch (e: Exception) {
                            lastErr.set("${java.net.URL(u).host}: ${e.javaClass.simpleName} ${e.message ?: ""}".trim())
                        }
                    }.apply { isDaemon = true; start() }
                }
                val t0 = System.currentTimeMillis()
                while (!done.get() && ths.any { it.isAlive } && System.currentTimeMillis() - t0 < 9000) {
                    try { Thread.sleep(100) } catch (_: InterruptedException) { return@Thread }
                }
                if (done.get()) return@Thread
                Bus.app("Real IP lookup failed (try ${round + 1}/3), last: ${lastErr.get()}")
                try { Thread.sleep(2500) } catch (_: InterruptedException) { return@Thread }
            }
        } finally {
            Bus.realIpFetching = false
        }
    }.apply { isDaemon = true }.start()
}

object Native {
    fun lib(ctx: Context, name: String) = File(ctx.applicationInfo.nativeLibraryDir, "lib$name.so")
}
