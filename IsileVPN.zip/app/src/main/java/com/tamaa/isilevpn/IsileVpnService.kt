package com.tamaa.isilevpn

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Intent
import android.content.pm.ServiceInfo
import android.net.VpnService
import android.os.Build
import android.os.ParcelFileDescriptor
import androidx.core.app.NotificationCompat
import hev.htproxy.TProxyService
import java.io.File
import java.io.IOException
import java.net.HttpURLConnection
import java.net.InetSocketAddress
import java.net.URL

class IsileVpnService : VpnService() {
    companion object {
        const val ACTION_START = "com.tamaa.isilevpn.START"
        const val ACTION_STOP = "com.tamaa.isilevpn.STOP"
        private const val CH = "vpn"
    }

    private var tun: ParcelFileDescriptor? = null
    private var xray: Process? = null
    private var ssh: SshTunnel? = null
    private var sampler: Thread? = null
    private var tproxyStarted = false

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            if (Bus.state != State.IDLE) Bus.log("Disconnect requested")
            stopAll()
            return START_NOT_STICKY
        }
        if (Bus.state != State.IDLE) return START_NOT_STICKY
        Bus.set(State.CONNECTING)
        goForeground("Connecting...")
        val p = Store.active(this)
        Thread {
            try {
                if (p == null) throw IOException("No config selected")
                connect(p)
            } catch (e: Throwable) {
                Bus.log("ERROR: ${e.message ?: e.javaClass.simpleName}")
                stopAll()
            }
        }.start()
        return START_NOT_STICKY
    }

    private fun connect(p: Profile) {
        Bus.log("Starting: ${p.name} (${p.typeLine()})")
        try {
            Class.forName("hev.htproxy.TProxyService")
        } catch (t: Throwable) {
            throw IOException("tun2socks library failed to load: ${t.javaClass.name}: ${t.cause?.message ?: t.message}")
        }
        Bus.log("Server: ${p.host}:${p.port}" + if (p.proxyHost.isNotBlank()) "  via proxy ${p.proxyHost}:${p.proxyPort}" else "")
        if (p.kind.isSsh) startSsh(p) else startXray(p)
        Bus.log("Creating VPN interface...")

        val b = Builder()
            .setSession("Isile VPN")
            .setMtu(1500)
            .addAddress("10.10.14.1", 30)
            .addRoute("0.0.0.0", 0)
            .addDnsServer("8.8.8.8")
            .addDnsServer("1.1.1.1")
        // نستثني تطبيقنا من النفق: اتصالات SSH/Xray تخرج مباشرة وبذلك لا توجد حلقة
        b.addDisallowedApplication(packageName)
        val fd = b.establish() ?: throw IOException("VPN permission not granted")
        tun = fd
        Bus.log("VPN interface ready")

        val cfg = File(filesDir, "hev.yml")
        cfg.writeText(
            """
            tunnel:
              mtu: 1500
              ipv4: 10.10.14.1
            socks5:
              port: ${XrayConfig.SOCKS_PORT}
              address: 127.0.0.1
              udp: 'udp'
            misc:
              log-level: warn
            """.trimIndent() + "\n"
        )
        tproxyStarted = true
        Bus.log("Starting tun2socks...")
        Thread {
            try {
                val ok = TProxyService.TProxyStartService(cfg.absolutePath, fd.fd)
                if (!ok) {
                    Bus.log("ERROR: tun2socks failed to start")
                    stopAll()
                }
            } catch (t: Throwable) {
                val cause = t.cause?.let { " / cause: ${it.javaClass.name}: ${it.message}" }.orEmpty()
                Bus.log("ERROR: tun2socks: ${t.javaClass.name}: ${t.message}$cause")
                t.stackTrace.take(6).forEach { Bus.log("    at $it") }
                stopAll()
            }
        }.start()
        Thread.sleep(800)
        if (tun == null) return
        Bus.set(State.CONNECTED)
        Bus.log("Connected")
        getSystemService(NotificationManager::class.java).notify(1, notif("Connected - ${p.name}"))
        startSampler()
        fetchIp()
    }

    private fun startXray(p: Profile) {
        Bus.log("Starting xray...")
        val cfg = File(filesDir, "xray.json")
        cfg.writeText(XrayConfig.build(p))
        val bin = Native.lib(this, "xray")
        if (!bin.exists()) throw IOException("libxray.so is not bundled in the APK")
        val pb = ProcessBuilder(bin.absolutePath, "run", "-c", cfg.absolutePath)
            .directory(filesDir).redirectErrorStream(true)
        pb.environment()["XRAY_LOCATION_ASSET"] = filesDir.absolutePath
        val pr = pb.start()
        xray = pr
        pipeLog(pr, "xray")
        Thread.sleep(1500)
        if (!pr.isAlive) throw IOException("xray exited (code ${pr.exitValue()}) - check the config/log")
        watch(pr, "xray")
        Bus.log("xray started")
    }

    private fun startSsh(p: Profile) {
        val t = SshTunnel(p) { stopAll() }
        ssh = t
        t.start(p.host, p.port, 25000)
    }

    /** يقيس السرعة كل ثانية من إحصائيات النفق (tx = رفع، rx = تنزيل). */
    private fun startSampler() {
        val th = Thread {
            var lastTx = -1L
            var lastRx = -1L
            while (!Thread.currentThread().isInterrupted && tproxyStarted) {
                try { Thread.sleep(1000) } catch (_: InterruptedException) { break }
                val s: LongArray? = try { TProxyService.TProxyGetStats() } catch (_: Throwable) { null }
                if (s == null || s.size < 4) continue
                val tx = s[1]
                val rx = s[3]
                if (lastTx >= 0) Bus.pushSpeed(maxOf(0L, rx - lastRx), maxOf(0L, tx - lastTx))
                lastTx = tx
                lastRx = rx
            }
        }
        th.isDaemon = true
        sampler = th
        th.start()
    }

    /** يجلب عنوان IP العام عبر منفذ SOCKS المحلي (أي من خلال النفق فعلاً). */
    private fun fetchIp() {
        Thread {
            for (i in 0 until 4) {
                if (Bus.state != State.CONNECTED) return@Thread
                val ip = try { httpGet("https://api.ipify.org") } catch (_: Exception) { null }
                if (ip != null) {
                    Bus.ip = ip
                    Bus.log("Public IP: $ip")
                    Bus.notifyChanged()
                    return@Thread
                }
                try { Thread.sleep(2000) } catch (_: InterruptedException) { return@Thread }
            }
            if (Bus.state == State.CONNECTED) {
                Bus.ip = "Unknown"
                Bus.notifyChanged()
            }
        }.apply { isDaemon = true }.start()
    }

    private fun httpGet(url: String): String? {
        val px = java.net.Proxy(java.net.Proxy.Type.SOCKS, InetSocketAddress("127.0.0.1", XrayConfig.SOCKS_PORT))
        val c = URL(url).openConnection(px) as HttpURLConnection
        c.connectTimeout = 8000
        c.readTimeout = 8000
        try {
            if (c.responseCode != 200) return null
            val t = c.inputStream.bufferedReader().readText().trim()
            return if (t.length in 7..45 && !t.contains('<')) t else null
        } finally {
            c.disconnect()
        }
    }

    private fun pipeLog(pr: Process, tag: String) {
        Thread {
            try { pr.inputStream.bufferedReader().forEachLine { Bus.log("[$tag] $it") } } catch (_: Exception) {}
        }.apply { isDaemon = true }.start()
    }

    private fun watch(pr: Process, tag: String) {
        Thread {
            try { pr.waitFor() } catch (_: Exception) {}
            if (Bus.state == State.CONNECTED) {
                Bus.log("$tag stopped unexpectedly")
                stopAll()
            }
        }.apply { isDaemon = true }.start()
    }

    @Synchronized
    private fun stopAll() {
        sampler?.interrupt(); sampler = null
        if (tproxyStarted) {
            tproxyStarted = false
            try { TProxyService.TProxyStopService() } catch (_: Throwable) {}
        }
        try { tun?.close() } catch (_: Exception) {}
        tun = null
        ssh?.stop(); ssh = null
        xray?.destroy(); xray = null
        if (Bus.state != State.IDLE) {
            Bus.set(State.IDLE)
            Bus.log("Disconnected")
        }
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    override fun onRevoke() {
        stopAll()
    }

    override fun onDestroy() {
        stopAll()
        super.onDestroy()
    }

    private fun goForeground(text: String) {
        val n = notif(text)
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else {
            startForeground(1, n)
        }
    }

    private fun notif(text: String): Notification {
        val nm = getSystemService(NotificationManager::class.java)
        if (Build.VERSION.SDK_INT >= 26) {
            nm.createNotificationChannel(NotificationChannel(CH, "VPN", NotificationManager.IMPORTANCE_LOW))
        }
        val open = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE
        )
        val stop = PendingIntent.getService(
            this, 1, Intent(this, IsileVpnService::class.java).setAction(ACTION_STOP), PendingIntent.FLAG_IMMUTABLE
        )
        return NotificationCompat.Builder(this, CH)
            .setSmallIcon(R.drawable.ic_launcher)
            .setContentTitle("Isile VPN")
            .setContentText(text)
            .setOngoing(true)
            .setContentIntent(open)
            .addAction(0, "Disconnect", stop)
            .build()
    }
}
