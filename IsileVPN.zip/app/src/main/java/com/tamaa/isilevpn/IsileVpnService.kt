package com.tamaa.isilevpn

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Intent
import android.content.pm.ServiceInfo
import android.net.VpnService
import android.os.Build
import android.os.ParcelFileDescriptor
import androidx.core.app.NotificationCompat
import hev.htproxy.TProxyService
import java.io.File
import java.io.IOException
import java.net.HttpURLConnection
import java.net.InetSocketAddress
import java.net.URL

class IsileVpnService : VpnService() {
    companion object {
        const val ACTION_START = "com.tamaa.isilevpn.START"
        const val ACTION_STOP = "com.tamaa.isilevpn.STOP"
        const val ACTION_RECONNECT = "com.tamaa.isilevpn.RECONNECT"
        private const val CH = "vpn"
        private val LOCK = Any()
        @Volatile private var current: Any? = null // محاولة الاتصال الحالية (على مستوى التطبيق كله)
    }

    /** كل محاولة اتصال لها رمز إلغاء خاص بها، حتى لا تتأثر محاولة جديدة بمحاولة قديمة. */
    private class Attempt {
        @Volatile var cancelled = false
    }

    private var tun: ParcelFileDescriptor? = null
    private var xray: Process? = null
    private var ssh: SshTunnel? = null
    private var sampler: Thread? = null
    @Volatile private var attempt: Attempt? = null
    @Volatile private var tproxyStarted = false
    @Volatile private var xrayFail: String? = null
    @Volatile private var connectedAt = 0L
    @Volatile private var profName = ""

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP -> {
                if (Bus.state != State.IDLE) Bus.log("Disconnect requested")
                stopAsync()
                return START_NOT_STICKY
            }
            ACTION_RECONNECT -> {
                profName = Store.active(this)?.name.orEmpty()
                goForeground("Reconnecting...")
                Bus.log("Reconnect requested")
                Thread {
                    teardown(stopService = false)
                    beginConnect(clearLog = false)
                }.start()
                return START_NOT_STICKY
            }
        }
        // يجب استدعاء startForeground دائمًا بعد startForegroundService وإلا يُغلق التطبيق
        profName = Store.active(this)?.name.orEmpty()
        goForeground("Connecting...")
        if (Bus.state != State.IDLE) return START_NOT_STICKY
        beginConnect(clearLog = true)
        return START_NOT_STICKY
    }

    private fun beginConnect(clearLog: Boolean) {
        val a = Attempt()
        attempt = a
        current = a
        if (clearLog) Bus.clear(false)
        Bus.set(State.CONNECTING)
        val p = Store.active(this)
        Thread {
            try {
                if (p == null) throw IOException("No config selected")
                connect(p, a)
            } catch (_: CancelledException) {
                // أُلغي الاتصال بطلب المستخدم
            } catch (e: Throwable) {
                // محاولة ملغاة (فصل أو إعادة اتصال) لا تُسقط المحاولة الجديدة
                if (!a.cancelled) {
                    Bus.log("ERROR: ${e.message ?: e.javaClass.simpleName}")
                    Bus.app("Connect failed: ${e.javaClass.name}: ${e.message}")
                    e.stackTrace.take(8).forEach { Bus.app("    at $it") }
                    teardown()
                }
            }
        }.start()
    }

    private fun check(a: Attempt) {
        if (a.cancelled) throw CancelledException()
    }

    private fun logHeader() {
        val v = try { packageManager.getPackageInfo(packageName, 0).versionName } catch (_: Exception) { "?" }
        Bus.log("Isile VPN v$v")
        Bus.log("Running on ${Build.MANUFACTURER.replaceFirstChar { it.uppercase() }} (${Build.DEVICE})")
        Bus.log("Android ${Build.VERSION.RELEASE} API-${Build.VERSION.SDK_INT} (${Build.SUPPORTED_ABIS.firstOrNull() ?: "?"})")
    }

    private fun connect(p: Profile, a: Attempt) {
        Bus.mask = if (p.locked)
            listOf(p.host, p.proxyHost, p.user, p.pass, p.secret, p.sni, p.wsHost).filter { it.length >= 3 }.distinct()
                .sortedByDescending { it.length }
        else emptyList()
        logHeader()
        Bus.log("Starting ${p.kind.label}: ${p.name}")
        try {
            Class.forName("hev.htproxy.TProxyService")
        } catch (t: Throwable) {
            Bus.app("tun2socks load error: ${t.javaClass.name}: ${t.cause?.message ?: t.message}")
            throw IOException("tun2socks library failed to load (see App log)")
        }
        check(a)
        if (p.kind.isSsh) startSsh(p, a) else startXray(p, a)
        check(a)

        Bus.log("Creating VPN interface...")
        val b = Builder()
            .setSession("Isile VPN")
            .setMtu(1500)
            .addAddress("10.10.14.1", 30)
            .addRoute("0.0.0.0", 0)
            .addDnsServer("8.8.8.8")
            .addDnsServer("1.1.1.1")
        // نستثني تطبيقنا من النفق: اتصالات SSH/Xray تخرج مباشرة وبذلك لا توجد حلقة
        b.addDisallowedApplication(packageName)
        val fd = b.establish() ?: throw IOException("VPN permission not granted")
        synchronized(LOCK) {
            if (a.cancelled) {
                try { fd.close() } catch (_: Exception) {}
                throw CancelledException()
            }
            tun = fd
        }
        Bus.app("VPN interface ready")

        val cfg = File(filesDir, "hev.yml")
        cfg.writeText(
            """
            tunnel:
              mtu: 1500
              ipv4: 10.10.14.1
            socks5:
              port: ${XrayConfig.SOCKS_PORT}
              address: 127.0.0.1
              udp: 'udp'
            misc:
              log-level: warn
            """.trimIndent() + "\n"
        )
        check(a)
        tproxyStarted = true
        val ok = try {
            TProxyService.TProxyStartService(cfg.absolutePath, fd.fd)
        } catch (t: Throwable) {
            Bus.app("tun2socks error: ${t.javaClass.name}: ${t.message}")
            false
        }
        if (!ok) throw IOException("tun2socks failed to start (see App log)")
        Thread.sleep(500)
        check(a)
        Bus.set(State.CONNECTED)
        Bus.log("SOCKS engine: hev-socks5-tunnel")
        Bus.log("Connected")
        connectedAt = System.currentTimeMillis()
        profName = p.name
        getSystemService(NotificationManager::class.java)
            .notify(1, notif("Connected", "↓ ${fmtSpeed(0)}   ↑ ${fmtSpeed(0)}", true))
        startSampler()
        fetchIp(a)
    }

    private fun alive(p: Process): Boolean = try { p.exitValue(); false } catch (_: IllegalThreadStateException) { true }

    private fun startXray(p: Profile, a: Attempt) {
        Bus.log("Starting Xray core...")
        xrayFail = null
        val cfg = File(filesDir, "xray.json")
        cfg.writeText(XrayConfig.build(p))
        val bin = Native.lib(this, "xray")
        if (!bin.exists()) throw IOException("libxray.so is not bundled in the APK")
        val pb = ProcessBuilder(bin.absolutePath, "run", "-c", cfg.absolutePath)
            .directory(filesDir).redirectErrorStream(true)
        pb.environment()["XRAY_LOCATION_ASSET"] = filesDir.absolutePath
        val pr = pb.start()
        synchronized(LOCK) {
            if (a.cancelled) {
                pr.destroy()
                throw CancelledException()
            }
            xray = pr
        }
        pipeLog(pr)
        for (i in 0 until 15) {
            Thread.sleep(100)
            check(a)
            if (!alive(pr)) break
        }
        if (!alive(pr)) {
            Thread.sleep(200) // نترك قارئ المخرجات يلتقط سبب الفشل
            throw IOException(xrayFail ?: "Xray exited (code ${pr.exitValue()}), see App log")
        }
        watch(pr)
        Bus.log("Xray started")
    }

    private fun startSsh(p: Profile, a: Attempt) {
        val t = SshTunnel(p) { if (ssh != null) { stopAsync() } }
        synchronized(LOCK) {
            if (a.cancelled) throw CancelledException()
            ssh = t
        }
        t.start(p.host, p.port, 25000)
    }

    /** يقيس السرعة كل ثانية من إحصائيات النفق (tx = رفع، rx = تنزيل). */
    private fun startSampler() {
        val th = Thread {
            var lastTx = -1L
            var lastRx = -1L
            while (!Thread.currentThread().isInterrupted && tproxyStarted) {
                try { Thread.sleep(1000) } catch (_: InterruptedException) { break }
                val s: LongArray? = try { TProxyService.TProxyGetStats() } catch (_: Throwable) { null }
                if (s == null || s.size < 4) continue
                val tx = s[1]
                val rx = s[3]
                if (lastTx >= 0) {
                    val down = maxOf(0L, rx - lastRx)
                    val up = maxOf(0L, tx - lastTx)
                    Bus.pushSpeed(down, up)
                    if (tproxyStarted && Bus.state == State.CONNECTED && !Thread.currentThread().isInterrupted) {
                        getSystemService(NotificationManager::class.java)
                            .notify(1, notif("Connected", "↓ ${fmtSpeed(down)}   ↑ ${fmtSpeed(up)}", true))
                    }
                }
                lastTx = tx
                lastRx = rx
            }
        }
        th.isDaemon = true
        sampler = th
        th.start()
    }

    /** يجلب عنوان IP العام عبر منفذ SOCKS المحلي (أي من خلال النفق فعلاً). */
    private fun fetchIp(a: Attempt) {
        Thread {
            for (i in 0 until 4) {
                if (a.cancelled || Bus.state != State.CONNECTED) return@Thread
                val ip = try { httpGet("https://api.ipify.org") } catch (_: Exception) { null }
                if (ip != null) {
                    Bus.ip = ip
                    Bus.log("Public IP: $ip")
                    Bus.notifyChanged()
                    return@Thread
                }
                try { Thread.sleep(2000) } catch (_: InterruptedException) { return@Thread }
            }
            if (!a.cancelled && Bus.state == State.CONNECTED) {
                Bus.ip = "Unknown"
                Bus.notifyChanged()
            }
        }.apply { isDaemon = true }.start()
    }

    private fun httpGet(url: String): String? {
        val px = java.net.Proxy(java.net.Proxy.Type.SOCKS, InetSocketAddress("127.0.0.1", XrayConfig.SOCKS_PORT))
        val c = URL(url).openConnection(px) as HttpURLConnection
        c.connectTimeout = 8000
        c.readTimeout = 8000
        try {
            if (c.responseCode != 200) return null
            val t = c.inputStream.bufferedReader().readText().trim()
            return if (t.length in 7..45 && !t.contains('<')) t else null
        } finally {
            c.disconnect()
        }
    }

    /** مخرجات xray كلها تذهب إلى سجل التطبيق؛ فقط سبب فشل التشغيل يظهر في سجل الاتصال. */
    private fun pipeLog(pr: Process) {
        Thread {
            try {
                pr.inputStream.bufferedReader().forEachLine { line ->
                    Bus.app("[xray] $line")
                    if (line.contains("Failed to start") || line.contains("failed to listen")) {
                        xrayFail = "Xray: " + line.substringAfterLast("> ").trim().take(160)
                    }
                }
            } catch (_: Exception) {}
        }.apply { isDaemon = true }.start()
    }

    private fun watch(pr: Process) {
        Thread {
            try { pr.waitFor() } catch (_: Exception) {}
            if (xray === pr && Bus.state == State.CONNECTED) {
                Bus.log("ERROR: Xray stopped unexpectedly")
                teardown()
            }
        }.apply { isDaemon = true }.start()
    }

    private fun stopAsync() {
        Thread { teardown() }.start()
    }

    /** إيقاف كل شيء بالترتيب، وانتظار موت xray قبل إعلان الحالة IDLE حتى لا يبقى المنفذ محجوزًا. */
    private fun teardown(stopService: Boolean = true) {
        synchronized(LOCK) {
            val mine = attempt
            mine?.cancelled = true
            sampler?.interrupt(); sampler = null
            if (tproxyStarted) {
                tproxyStarted = false
                try { TProxyService.TProxyStopService() } catch (_: Throwable) {}
            }
            try { tun?.close() } catch (_: Exception) {}
            tun = null
            ssh?.stop(); ssh = null
            val x = xray
            xray = null
            if (x != null) {
                x.destroy()
                var i = 0
                while (alive(x) && i < 30) {
                    try { Thread.sleep(100) } catch (_: InterruptedException) { break }
                    i++
                }
            }
            // نغيّر الحالة فقط إن كانت المحاولة الحالية تخصنا (لا نؤثر على اتصال جديد)
            if (mine === current && Bus.state != State.IDLE) {
                Bus.set(State.IDLE)
                Bus.log("Disconnected")
            }
        }
        if (stopService) {
            try { stopForeground(STOP_FOREGROUND_REMOVE) } catch (_: Exception) {}
            try { getSystemService(NotificationManager::class.java).cancel(1) } catch (_: Exception) {}
            stopSelf()
        }
    }

    override fun onRevoke() {
        stopAsync()
    }

    override fun onDestroy() {
        attempt?.cancelled = true
        stopAsync()
        super.onDestroy()
    }

    private fun goForeground(title: String) {
        val n = notif(title, "", false)
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else {
            startForeground(1, n)
        }
    }

    private fun fmtSpeed(b: Long): String = when {
        b < 1024 -> "$b B/s"
        b < 1024 * 1024 -> String.format(java.util.Locale.US, "%.1f KB/s", b / 1024.0)
        else -> String.format(java.util.Locale.US, "%.2f MB/s", b / 1048576.0)
    }

    /** connected=true: يعرض عدّادًا حيًّا لمدة الاتصال (يديره النظام) ويستعمل وقت الاتصال كمرجع. */
    private fun notif(title: String, text: String, connected: Boolean): Notification {
        val nm = getSystemService(NotificationManager::class.java)
        if (Build.VERSION.SDK_INT >= 26) {
            nm.createNotificationChannel(NotificationChannel(CH, "VPN", NotificationManager.IMPORTANCE_LOW))
        }
        val open = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE
        )
        val stop = PendingIntent.getService(
            this, 1, Intent(this, IsileVpnService::class.java).setAction(ACTION_STOP), PendingIntent.FLAG_IMMUTABLE
        )
        val reconnect = PendingIntent.getService(
            this, 2, Intent(this, IsileVpnService::class.java).setAction(ACTION_RECONNECT), PendingIntent.FLAG_IMMUTABLE
        )
        val b = NotificationCompat.Builder(this, CH)
            .setSmallIcon(R.drawable.ic_notif)
            .setContentTitle(title)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setContentIntent(open)
            .addAction(0, "Disconnect", stop)
            .addAction(0, "Reconnect", reconnect)
        if (text.isNotEmpty()) b.setContentText(text)
        if (profName.isNotEmpty()) b.setSubText(profName)
        if (connected && connectedAt > 0) b.setWhen(connectedAt).setUsesChronometer(true).setShowWhen(true)
        else b.setShowWhen(false)
        return b.build()
    }
}
