package com.tamaa.isilevpn

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Intent
import android.content.pm.ServiceInfo
import android.net.VpnService
import android.os.Build
import android.os.ParcelFileDescriptor
import androidx.core.app.NotificationCompat
import hev.htproxy.TProxyService
import java.io.File
import java.io.IOException

class IsileVpnService : VpnService() {
    companion object {
        const val ACTION_START = "com.tamaa.isilevpn.START"
        const val ACTION_STOP = "com.tamaa.isilevpn.STOP"
        const val DNSTT_PORT = 7000
        private const val CH = "vpn"
    }

    private var tun: ParcelFileDescriptor? = null
    private var xray: Process? = null
    private var dnstt: Process? = null
    private var ssh: SshTunnel? = null
    private var tproxyStarted = false

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            stopAll()
            return START_NOT_STICKY
        }
        if (Bus.state != State.IDLE) return START_NOT_STICKY
        Bus.set(State.CONNECTING)
        goForeground("Connecting...")
        val p = Store.load(this)
        Thread {
            try {
                connect(p)
            } catch (e: Throwable) {
                Bus.log("ERROR: ${e.message ?: e.javaClass.simpleName}")
                stopAll()
            }
        }.start()
        return START_NOT_STICKY
    }

    private fun connect(p: Profile) {
        Bus.log("Starting: ${p.mode.label}")
        when (p.mode) {
            Mode.LINK -> startXray(p)
            Mode.SLOWDNS -> {
                startDnstt(p)
                startSsh(p, "127.0.0.1", DNSTT_PORT, 60000)
            }
            else -> startSsh(p, p.host, p.port, 25000)
        }

        val b = Builder()
            .setSession("Isile VPN")
            .setMtu(1500)
            .addAddress("10.10.14.1", 30)
            .addRoute("0.0.0.0", 0)
            .addDnsServer("8.8.8.8")
            .addDnsServer("1.1.1.1")
        // نستثني تطبيقنا من النفق: اتصالات SSH/Xray/DNSTT تخرج مباشرة وبذلك لا توجد حلقة
        b.addDisallowedApplication(packageName)
        val fd = b.establish() ?: throw IOException("VPN permission not granted")
        tun = fd

        val cfg = File(filesDir, "hev.yml")
        cfg.writeText(
            """
            tunnel:
              mtu: 1500
              ipv4: 10.10.14.1
            socks5:
              port: ${XrayConfig.SOCKS_PORT}
              address: 127.0.0.1
              udp: 'udp'
            misc:
              log-level: warn
            """.trimIndent() + "\n"
        )
        tproxyStarted = true
        Thread {
            try {
                TProxyService.TProxyStartService(cfg.absolutePath, fd.fd)
            } catch (t: Throwable) {
                Bus.log("tun2socks error: ${t.message ?: t.javaClass.simpleName}")
                stopAll()
            }
        }.start()
        Thread.sleep(800)
        if (tun == null) return
        Bus.set(State.CONNECTED)
        Bus.log("Connected")
        getSystemService(NotificationManager::class.java).notify(1, notif("Connected - ${p.mode.label}"))
    }

    private fun startXray(p: Profile) {
        val cfg = File(filesDir, "xray.json")
        cfg.writeText(XrayConfig.build(p.link))
        val bin = Native.lib(this, "xray")
        if (!bin.exists()) throw IOException("libxray.so is not bundled in the APK")
        val pb = ProcessBuilder(bin.absolutePath, "run", "-c", cfg.absolutePath)
            .directory(filesDir).redirectErrorStream(true)
        pb.environment()["XRAY_LOCATION_ASSET"] = filesDir.absolutePath
        val pr = pb.start()
        xray = pr
        pipeLog(pr, "xray")
        Thread.sleep(1500)
        if (!pr.isAlive) throw IOException("xray exited (code ${pr.exitValue()}) - check the link/log")
        watch(pr, "xray")
        Bus.log("xray started")
    }

    private fun startDnstt(p: Profile) {
        val bin = Native.lib(this, "dnstt")
        if (!bin.exists()) throw IOException("libdnstt.so is not bundled (Go build failed?)")
        val resolver = p.dnsResolver.trim().let { if (it.contains(":")) it else "$it:53" }
        val pb = ProcessBuilder(
            bin.absolutePath, "-udp", resolver, "-pubkey", p.dnsPubKey.trim(),
            p.dnsDomain.trim(), "127.0.0.1:$DNSTT_PORT"
        ).directory(filesDir).redirectErrorStream(true)
        val pr = pb.start()
        dnstt = pr
        pipeLog(pr, "dnstt")
        Thread.sleep(2000)
        if (!pr.isAlive) throw IOException("dnstt exited (code ${pr.exitValue()})")
        watch(pr, "dnstt")
        Bus.log("dnstt started via $resolver")
    }

    private fun startSsh(p: Profile, host: String, port: Int, timeout: Int) {
        val t = SshTunnel(p) { stopAll() }
        ssh = t
        t.start(host, port, timeout)
    }

    private fun pipeLog(pr: Process, tag: String) {
        Thread {
            try { pr.inputStream.bufferedReader().forEachLine { Bus.log("[$tag] $it") } } catch (_: Exception) {}
        }.apply { isDaemon = true }.start()
    }

    private fun watch(pr: Process, tag: String) {
        Thread {
            try { pr.waitFor() } catch (_: Exception) {}
            if (Bus.state == State.CONNECTED) {
                Bus.log("$tag stopped unexpectedly")
                stopAll()
            }
        }.apply { isDaemon = true }.start()
    }

    @Synchronized
    private fun stopAll() {
        if (tproxyStarted) {
            try { TProxyService.TProxyStopService() } catch (_: Throwable) {}
            tproxyStarted = false
        }
        try { tun?.close() } catch (_: Exception) {}
        tun = null
        ssh?.stop(); ssh = null
        xray?.destroy(); xray = null
        dnstt?.destroy(); dnstt = null
        if (Bus.state != State.IDLE) {
            Bus.set(State.IDLE)
            Bus.log("Disconnected")
        }
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    override fun onRevoke() {
        stopAll()
    }

    override fun onDestroy() {
        stopAll()
        super.onDestroy()
    }

    private fun goForeground(text: String) {
        val n = notif(text)
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else {
            startForeground(1, n)
        }
    }

    private fun notif(text: String): Notification {
        val nm = getSystemService(NotificationManager::class.java)
        if (Build.VERSION.SDK_INT >= 26) {
            nm.createNotificationChannel(NotificationChannel(CH, "VPN", NotificationManager.IMPORTANCE_LOW))
        }
        val open = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE
        )
        val stop = PendingIntent.getService(
            this, 1, Intent(this, IsileVpnService::class.java).setAction(ACTION_STOP), PendingIntent.FLAG_IMMUTABLE
        )
        return NotificationCompat.Builder(this, CH)
            .setSmallIcon(R.drawable.ic_launcher)
            .setContentTitle("Isile VPN")
            .setContentText(text)
            .setOngoing(true)
            .setContentIntent(open)
            .addAction(0, "Disconnect", stop)
            .build()
    }
}
