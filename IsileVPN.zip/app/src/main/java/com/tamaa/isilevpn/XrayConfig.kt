package com.tamaa.isilevpn

import org.json.JSONArray
import org.json.JSONObject

/** يبني إعداد Xray من Profile (vless / vmess / trojan) مع منفذ SOCKS محلي. */
object XrayConfig {
    const val SOCKS_PORT = 10808

    fun build(p: Profile): String {
        val ob = outbound(p).put("tag", "proxy")
        val muxOk = p.mux && !(p.kind == Kind.VLESS && p.flow.isNotEmpty())
        if (muxOk) ob.put("mux", JSONObject().put("enabled", true).put("concurrency", 8))
        val inbound = JSONObject()
            .put("tag", "socks")
            .put("listen", "127.0.0.1")
            .put("port", SOCKS_PORT)
            .put("protocol", "socks")
            .put("settings", JSONObject().put("auth", "noauth").put("udp", true))
        return JSONObject()
            .put("log", JSONObject().put("loglevel", "warning"))
            .put("inbounds", JSONArray().put(inbound))
            .put(
                "outbounds",
                JSONArray().put(ob).put(JSONObject().put("protocol", "freedom").put("tag", "direct"))
            )
            .toString(2)
    }

    private fun vnext(protocol: String, p: Profile, user: JSONObject): JSONObject {
        val server = JSONObject().put("address", p.host).put("port", p.port).put("users", JSONArray().put(user))
        return JSONObject().put("protocol", protocol)
            .put("settings", JSONObject().put("vnext", JSONArray().put(server)))
    }

    private fun outbound(p: Profile): JSONObject {
        val ob = when (p.kind) {
            Kind.VLESS -> {
                val u = JSONObject().put("id", p.secret).put("encryption", p.encryption.ifEmpty { "none" })
                if (p.flow.isNotEmpty()) u.put("flow", p.flow)
                vnext("vless", p, u)
            }
            Kind.VMESS -> {
                val u = JSONObject().put("id", p.secret).put("alterId", p.alterId)
                    .put("security", p.vmessScy.ifEmpty { "auto" })
                vnext("vmess", p, u)
            }
            Kind.TROJAN -> {
                val server = JSONObject().put("address", p.host).put("port", p.port).put("password", p.secret)
                JSONObject().put("protocol", "trojan")
                    .put("settings", JSONObject().put("servers", JSONArray().put(server)))
            }
            Kind.SSH -> throw IllegalArgumentException("SSH is not an Xray protocol")
        }
        return ob.put("streamSettings", stream(p))
    }

    private fun stream(p: Profile): JSONObject {
        val net = if (p.ws) "ws" else when (p.network) {
            "grpc", "httpupgrade", "xhttp" -> p.network
            else -> "tcp"
        }
        val s = JSONObject().put("network", net)
        val host = p.wsHost.takeIf { it.isNotEmpty() }
        val path = p.wsPath.ifEmpty { "/" }
        when (net) {
            "ws" -> {
                val ws = JSONObject().put("path", path)
                if (host != null) ws.put("headers", JSONObject().put("Host", host))
                s.put("wsSettings", ws)
            }
            "grpc" -> s.put("grpcSettings", JSONObject().put("serviceName", p.serviceName))
            "httpupgrade" -> {
                val h = JSONObject().put("path", path)
                if (host != null) h.put("host", host)
                s.put("httpupgradeSettings", h)
            }
            "xhttp" -> {
                val h = JSONObject().put("path", path)
                if (host != null) h.put("host", host)
                s.put("xhttpSettings", h)
            }
        }
        val sec = if (!p.tls) "none" else if (p.security == "reality") "reality" else "tls"
        s.put("security", sec)
        val sni = p.sni.ifEmpty { p.wsHost }.takeIf { it.isNotEmpty() }
        if (sec == "tls") {
            val t = JSONObject()
            if (p.fingerprint.isNotEmpty()) t.put("fingerprint", p.fingerprint)
            if (sni != null) t.put("serverName", sni)
            if (p.alpn.isNotBlank()) {
                val arr = JSONArray()
                p.alpn.split(',').map { it.trim() }.filter { it.isNotEmpty() }.forEach { arr.put(it) }
                t.put("alpn", arr)
            }
            if (p.insecure) t.put("allowInsecure", true)
            s.put("tlsSettings", t)
        } else if (sec == "reality") {
            val r = JSONObject()
                .put("fingerprint", p.fingerprint.ifEmpty { "chrome" })
                .put("publicKey", p.pbk)
                .put("shortId", p.sid)
                .put("spiderX", p.spx)
            if (sni != null) r.put("serverName", sni)
            s.put("realitySettings", r)
        }
        return s
    }
}
