package com.tamaa.isilevpn

import android.net.Uri
import android.util.Base64
import org.json.JSONArray
import org.json.JSONObject

/** يحوّل روابط vless:// vmess:// trojan:// إلى إعداد Xray مع منفذ SOCKS محلي. */
object XrayConfig {
    const val SOCKS_PORT = 10808

    fun build(link: String): String {
        val l = link.trim()
        val outbound = when {
            l.startsWith("vless://") -> vless(l)
            l.startsWith("vmess://") -> vmess(l)
            l.startsWith("trojan://") -> trojan(l)
            else -> throw IllegalArgumentException("Unsupported link. Use vless://, vmess:// or trojan://")
        }
        outbound.put("tag", "proxy")
        val inbound = JSONObject()
            .put("tag", "socks")
            .put("listen", "127.0.0.1")
            .put("port", SOCKS_PORT)
            .put("protocol", "socks")
            .put("settings", JSONObject().put("auth", "noauth").put("udp", true))
        return JSONObject()
            .put("log", JSONObject().put("loglevel", "warning"))
            .put("inbounds", JSONArray().put(inbound))
            .put(
                "outbounds",
                JSONArray().put(outbound).put(JSONObject().put("protocol", "freedom").put("tag", "direct"))
            )
            .toString(2)
    }

    private fun queryMap(u: Uri): Map<String, String> {
        val m = HashMap<String, String>()
        for (k in u.queryParameterNames) u.getQueryParameter(k)?.let { m[k] = it }
        return m
    }

    private fun vless(l: String): JSONObject {
        val u = Uri.parse(l)
        val q = queryMap(u)
        val host = u.host ?: error("Missing host")
        val port = if (u.port > 0) u.port else 443
        val id = u.userInfo ?: error("Missing UUID")
        val user = JSONObject().put("id", id).put("encryption", q["encryption"] ?: "none")
        q["flow"]?.takeIf { it.isNotEmpty() }?.let { user.put("flow", it) }
        val server = JSONObject().put("address", host).put("port", port).put("users", JSONArray().put(user))
        return JSONObject().put("protocol", "vless")
            .put("settings", JSONObject().put("vnext", JSONArray().put(server)))
            .put("streamSettings", stream(q))
    }

    private fun vmess(l: String): JSONObject {
        var b64 = l.removePrefix("vmess://").substringBefore('#').trim()
        b64 = b64.replace('-', '+').replace('_', '/')
        val j = JSONObject(String(Base64.decode(b64, Base64.DEFAULT)))
        val q = HashMap<String, String>()
        q["type"] = j.optString("net", "tcp")
        q["security"] = if (j.optString("tls") == "tls") "tls" else "none"
        q["sni"] = j.optString("sni")
        q["host"] = j.optString("host")
        q["path"] = j.optString("path")
        q["serviceName"] = j.optString("path")
        q["fp"] = j.optString("fp")
        q["alpn"] = j.optString("alpn")
        val user = JSONObject().put("id", j.getString("id"))
            .put("alterId", j.optString("aid", "0").toIntOrNull() ?: 0)
            .put("security", j.optString("scy").ifEmpty { "auto" })
        val server = JSONObject().put("address", j.getString("add"))
            .put("port", j.optString("port", "443").toInt())
            .put("users", JSONArray().put(user))
        return JSONObject().put("protocol", "vmess")
            .put("settings", JSONObject().put("vnext", JSONArray().put(server)))
            .put("streamSettings", stream(q))
    }

    private fun trojan(l: String): JSONObject {
        val u = Uri.parse(l)
        val q = HashMap(queryMap(u))
        if (!q.containsKey("security")) q["security"] = "tls"
        val server = JSONObject().put("address", u.host ?: error("Missing host"))
            .put("port", if (u.port > 0) u.port else 443)
            .put("password", u.userInfo ?: error("Missing password"))
        return JSONObject().put("protocol", "trojan")
            .put("settings", JSONObject().put("servers", JSONArray().put(server)))
            .put("streamSettings", stream(q))
    }

    private fun stream(p: Map<String, String>): JSONObject {
        val net = when (val t = p["type"] ?: "tcp") {
            "ws", "grpc", "httpupgrade", "xhttp", "tcp" -> t
            "splithttp" -> "xhttp"
            else -> "tcp"
        }
        val s = JSONObject().put("network", net)
        val host = p["host"]?.takeIf { it.isNotEmpty() }
        val path = p["path"]?.takeIf { it.isNotEmpty() } ?: "/"
        when (net) {
            "ws" -> {
                val ws = JSONObject().put("path", path)
                if (host != null) ws.put("headers", JSONObject().put("Host", host))
                s.put("wsSettings", ws)
            }
            "grpc" -> s.put("grpcSettings", JSONObject().put("serviceName", p["serviceName"] ?: ""))
            "httpupgrade" -> {
                val h = JSONObject().put("path", path)
                if (host != null) h.put("host", host)
                s.put("httpupgradeSettings", h)
            }
            "xhttp" -> {
                val h = JSONObject().put("path", path)
                if (host != null) h.put("host", host)
                s.put("xhttpSettings", h)
            }
        }
        val sec = p["security"]?.takeIf { it.isNotEmpty() } ?: "none"
        s.put("security", sec)
        val sni = p["sni"]?.takeIf { it.isNotEmpty() } ?: host
        val fp = p["fp"]?.takeIf { it.isNotEmpty() } ?: "chrome"
        if (sec == "tls") {
            val t = JSONObject().put("fingerprint", fp)
            if (sni != null) t.put("serverName", sni)
            p["alpn"]?.takeIf { it.isNotEmpty() }?.let { a ->
                val arr = JSONArray()
                a.split(',').forEach { arr.put(it.trim()) }
                t.put("alpn", arr)
            }
            s.put("tlsSettings", t)
        } else if (sec == "reality") {
            val r = JSONObject().put("fingerprint", fp)
                .put("publicKey", p["pbk"] ?: "")
                .put("shortId", p["sid"] ?: "")
                .put("spiderX", p["spx"] ?: "")
            if (sni != null) r.put("serverName", sni)
            s.put("realitySettings", r)
        }
        return s
    }
}
