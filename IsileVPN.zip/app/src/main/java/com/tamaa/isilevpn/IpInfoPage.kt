package com.tamaa.isilevpn

import android.app.Activity
import android.graphics.Outline
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.ViewOutlineProvider
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.TextView
import androidx.core.content.ContextCompat

/** صفحة What's my IP: خريطة + بطاقة (علم، المزوّد، العنوان) + باقي التفاصيل. */
class IpInfoPage(private val act: Activity, private val root: View) {
    private val map: ImageView = root.findViewById(R.id.ipMap)
    private val progress: ProgressBar = root.findViewById(R.id.ipProgress)
    private val mapMsg: TextView = root.findViewById(R.id.ipMapMsg)
    private val flag: ImageView = root.findViewById(R.id.ipFlag)
    private val flagEmoji: TextView = root.findViewById(R.id.ipFlagEmoji)
    private val place: TextView = root.findViewById(R.id.ipPlace)
    private val addr: TextView = root.findViewById(R.id.ipAddr)
    private val error: TextView = root.findViewById(R.id.ipError)
    private val rows: LinearLayout = root.findViewById(R.id.ipRows)
    private val mode: TextView = root.findViewById(R.id.ipMode)

    private var req = 0
    var loadedState: State? = null
        private set

    private fun dp(v: Int) = (v * act.resources.displayMetrics.density + 0.5f).toInt()
    private fun col(id: Int) = ContextCompat.getColor(act, id)
    private fun ui(id: Int, block: () -> Unit) {
        act.runOnUiThread { if (id == req && !act.isDestroyed) block() }
    }

    init {
        flag.clipToOutline = true
        flag.outlineProvider = object : ViewOutlineProvider() {
            override fun getOutline(v: View, o: Outline) = o.setRoundRect(0, 0, v.width, v.height, dp(6).toFloat())
        }
        root.findViewById<View>(R.id.ipRefresh).setOnClickListener { load(Bus.state) }
    }

    fun load(state: State) {
        val id = ++req
        val via = state == State.CONNECTED
        loadedState = state
        mode.text = if (via) "Checked through the VPN tunnel" else "Checked on your direct connection (VPN off)"
        progress.visibility = View.VISIBLE
        mapMsg.visibility = View.GONE
        error.visibility = View.GONE
        map.setImageDrawable(null)
        flag.setImageDrawable(null)
        flag.visibility = View.VISIBLE
        flagEmoji.visibility = View.GONE
        place.text = "Loading..."
        addr.text = ""
        rows.removeAllViews()
        Thread {
            val data = try {
                IpInfo.fetch(via)
            } catch (e: Exception) {
                ui(id) {
                    progress.visibility = View.GONE
                    place.text = "Unavailable"
                    error.visibility = View.VISIBLE
                    error.text = "Could not get IP info: ${e.message ?: "network error"}"
                }
                return@Thread
            }
            ui(id) { show(data) }
            // الخريطة والعلم في خيطين منفصلين كي لا يتأخر ظهور البيانات
            Thread {
                val bmp = try {
                    if (data.lat != null && data.lon != null) MapRender.render(data.lat, data.lon, via) else null
                } catch (_: Throwable) { null }
                ui(id) {
                    progress.visibility = View.GONE
                    if (bmp != null) map.setImageBitmap(bmp)
                    else {
                        mapMsg.visibility = View.VISIBLE
                        mapMsg.text = "Map unavailable"
                    }
                }
            }.apply { isDaemon = true }.start()
            Thread {
                val bmp = try { IpInfo.flagBitmap(data.countryCode, via) } catch (_: Throwable) { null }
                ui(id) {
                    if (bmp != null) flag.setImageBitmap(bmp)
                    else {
                        flag.visibility = View.GONE
                        flagEmoji.visibility = View.VISIBLE
                        flagEmoji.text = IpInfo.flagEmoji(data.countryCode)
                    }
                }
            }.apply { isDaemon = true }.start()
        }.apply { isDaemon = true }.start()
    }

    private fun show(d: IpData) {
        place.text = d.org.ifEmpty { d.isp }.ifEmpty { d.country }.ifEmpty { "Unknown" }
        addr.text = d.ip
        rows.removeAllViews()
        val coords = if (d.lat != null && d.lon != null) String.format(java.util.Locale.US, "%.4f, %.4f", d.lat, d.lon) else ""
        val items = listOf(
            "Country" to d.country,
            "Continent" to d.continent,
            "Region" to d.region,
            "City" to d.city,
            "Postal code" to d.postal,
            "ASN" to d.asn,
            "Organization" to d.org,
            "ISP" to d.isp,
            "Domain" to d.domain,
            "Coordinates" to coords,
            "Timezone" to d.timezone,
            "Currency" to d.currency,
            "Calling code" to d.callingCode
        ) + d.extra
        var first = true
        for ((k, v) in items) {
            if (v.isBlank()) continue
            if (!first) rows.addView(View(act).apply { setBackgroundColor(col(R.color.outline)) },
                LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 1))
            first = false
            val row = LinearLayout(act).apply {
                orientation = LinearLayout.HORIZONTAL
                setPadding(dp(4), dp(11), dp(4), dp(11))
            }
            row.addView(TextView(act).apply {
                text = k
                textSize = 14f
                setTextColor(col(R.color.text_dim))
            }, LinearLayout.LayoutParams(dp(120), ViewGroup.LayoutParams.WRAP_CONTENT))
            row.addView(TextView(act).apply {
                text = v
                textSize = 14f
                gravity = Gravity.START
                setTextColor(col(R.color.text))
                setTextIsSelectable(true)
            }, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
            rows.addView(row)
        }
    }
}
