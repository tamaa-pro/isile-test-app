package com.tamaa.isilevpn

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.util.UUID

enum class Kind(val label: String) {
    SSH("SSH"), VLESS("VLESS"), VMESS("VMess"), TROJAN("Trojan");

    val isSsh get() = this == SSH
}

const val DEFAULT_PAYLOAD = "GET / HTTP/1.1[crlf]Host: [host][crlf]Upgrade: websocket[crlf][crlf]"

data class Profile(
    var uid: String = UUID.randomUUID().toString(),
    var name: String = "",
    var kind: Kind = Kind.SSH,
    var host: String = "",
    var port: Int = 22,
    // SSH
    var user: String = "",
    var pass: String = "",
    var payloadOn: Boolean = false,
    var payload: String = DEFAULT_PAYLOAD,
    var proxyHost: String = "",
    var proxyPort: Int = 8080,
    // V2Ray: UUID (vless/vmess) أو كلمة المرور (trojan)
    var secret: String = "",
    // مشترك
    var ws: Boolean = false,
    var wsPath: String = "/",
    var wsHost: String = "",
    var tls: Boolean = false,
    var sni: String = "",
    var tlsVersion: String = "Auto",
    var fingerprint: String = "chrome",
    var alpn: String = "",
    var insecure: Boolean = false,
    var mux: Boolean = false,
    // حقول مخفية تأتي من الروابط (تُحفظ كما هي)
    var network: String = "tcp",
    var security: String = "",
    var flow: String = "",
    var pbk: String = "",
    var sid: String = "",
    var spx: String = "",
    var alterId: Int = 0,
    var vmessScy: String = "auto",
    var encryption: String = "none",
    var serviceName: String = "",
    // كونفيج مستورد مغلق: لا يُعرض محتواه ولا يُعدَّل ولا يُشارَك
    var locked: Boolean = false
) {
    /** مثال: "VLESS · WS · TLS" */
    fun typeLine(): String {
        val parts = mutableListOf(kind.label)
        if (ws) parts += "WS"
        if (kind.isSsh && payloadOn) parts += "Payload"
        if (tls) parts += "TLS"
        return parts.joinToString(" · ")
    }

    fun toJson(): JSONObject = JSONObject().apply {
        put("uid", uid); put("name", name); put("kind", kind.name)
        put("host", host); put("port", port)
        put("user", user); put("pass", pass)
        put("payloadOn", payloadOn); put("payload", payload)
        put("proxyHost", proxyHost); put("proxyPort", proxyPort)
        put("secret", secret)
        put("ws", ws); put("wsPath", wsPath); put("wsHost", wsHost)
        put("tls", tls); put("sni", sni); put("tlsVersion", tlsVersion)
        put("fingerprint", fingerprint); put("alpn", alpn)
        put("insecure", insecure); put("mux", mux)
        put("network", network); put("security", security); put("flow", flow)
        put("pbk", pbk); put("sid", sid); put("spx", spx)
        put("alterId", alterId); put("vmessScy", vmessScy)
        put("encryption", encryption); put("serviceName", serviceName)
        put("locked", locked)
    }

    companion object {
        fun fromJson(j: JSONObject): Profile {
            val d = Profile()
            return Profile(
                uid = j.optString("uid").ifEmpty { d.uid },
                name = j.optString("name", d.name),
                kind = runCatching { Kind.valueOf(j.optString("kind")) }.getOrDefault(d.kind),
                host = j.optString("host", d.host),
                port = j.optInt("port", d.port),
                user = j.optString("user", d.user),
                pass = j.optString("pass", d.pass),
                payloadOn = j.optBoolean("payloadOn", d.payloadOn),
                payload = j.optString("payload", d.payload),
                proxyHost = j.optString("proxyHost", d.proxyHost),
                proxyPort = j.optInt("proxyPort", d.proxyPort),
                secret = j.optString("secret", d.secret),
                ws = j.optBoolean("ws", d.ws),
                wsPath = j.optString("wsPath", d.wsPath),
                wsHost = j.optString("wsHost", d.wsHost),
                tls = j.optBoolean("tls", d.tls),
                sni = j.optString("sni", d.sni),
                tlsVersion = j.optString("tlsVersion", d.tlsVersion),
                fingerprint = j.optString("fingerprint", d.fingerprint),
                alpn = j.optString("alpn", d.alpn),
                insecure = j.optBoolean("insecure", d.insecure),
                mux = j.optBoolean("mux", d.mux),
                network = j.optString("network", d.network),
                security = j.optString("security", d.security),
                flow = j.optString("flow", d.flow),
                pbk = j.optString("pbk", d.pbk),
                sid = j.optString("sid", d.sid),
                spx = j.optString("spx", d.spx),
                alterId = j.optInt("alterId", d.alterId),
                vmessScy = j.optString("vmessScy", d.vmessScy),
                encryption = j.optString("encryption", d.encryption),
                serviceName = j.optString("serviceName", d.serviceName),
                locked = j.optBoolean("locked", d.locked)
            )
        }
    }
}

/** تخزين الكونفيجات (قائمة) + الكونفيج النشط. */
object Store {
    private fun sp(c: Context) = c.getSharedPreferences("isile_configs", Context.MODE_PRIVATE)

    fun all(c: Context): MutableList<Profile> {
        val s = sp(c).getString("list", null) ?: return mutableListOf()
        return runCatching {
            val a = JSONArray(s)
            MutableList(a.length()) { Profile.fromJson(a.getJSONObject(it)) }
        }.getOrDefault(mutableListOf())
    }

    private fun saveAll(c: Context, list: List<Profile>) {
        val a = JSONArray()
        list.forEach { a.put(it.toJson()) }
        sp(c).edit().putString("list", a.toString()).apply()
    }

    fun activeId(c: Context): String? = sp(c).getString("active", null)

    fun setActive(c: Context, uid: String?) {
        sp(c).edit().putString("active", uid).apply()
    }

    fun active(c: Context): Profile? {
        val id = activeId(c) ?: return null
        return all(c).firstOrNull { it.uid == id }
    }

    fun upsert(c: Context, p: Profile) {
        val l = all(c)
        val i = l.indexOfFirst { it.uid == p.uid }
        if (i >= 0) l[i] = p else l.add(p)
        saveAll(c, l)
    }

    fun delete(c: Context, uid: String) {
        val l = all(c)
        l.removeAll { it.uid == uid }
        saveAll(c, l)
        if (activeId(c) == uid) setActive(c, l.firstOrNull()?.uid)
    }
}
