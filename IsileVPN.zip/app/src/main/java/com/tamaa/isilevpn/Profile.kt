package com.tamaa.isilevpn

import android.content.Context
import org.json.JSONObject

enum class Mode(val label: String) {
    SSH_DIRECT("SSH Direct"),
    SSH_PAYLOAD("SSH + HTTP Payload"),
    SSH_WS("SSH + WebSocket"),
    SSH_SSL("SSH + SSL/TLS (SNI)"),
    SLOWDNS("SlowDNS (DNSTT)"),
    LINK("VLESS / VMess / Trojan");

    val isSsh get() = this == SSH_DIRECT || this == SSH_PAYLOAD || this == SSH_WS || this == SSH_SSL
}

data class Profile(
    var mode: Mode = Mode.SSH_DIRECT,
    var host: String = "",
    var port: Int = 22,
    var user: String = "",
    var pass: String = "",
    var tls: Boolean = false,
    var sni: String = "",
    var payload: String = "GET / HTTP/1.1[crlf]Host: [host][crlf]Upgrade: websocket[crlf][crlf]",
    var wsPath: String = "/",
    var wsHost: String = "",
    var dnsResolver: String = "8.8.8.8",
    var dnsDomain: String = "",
    var dnsPubKey: String = "",
    var link: String = ""
) {
    fun toJson(): String = JSONObject().apply {
        put("mode", mode.name); put("host", host); put("port", port)
        put("user", user); put("pass", pass); put("tls", tls); put("sni", sni)
        put("payload", payload); put("wsPath", wsPath); put("wsHost", wsHost)
        put("dnsResolver", dnsResolver); put("dnsDomain", dnsDomain)
        put("dnsPubKey", dnsPubKey); put("link", link)
    }.toString()

    companion object {
        fun fromJson(s: String): Profile {
            val d = Profile()
            val j = JSONObject(s)
            return Profile(
                mode = runCatching { Mode.valueOf(j.optString("mode")) }.getOrDefault(d.mode),
                host = j.optString("host", d.host),
                port = j.optInt("port", d.port),
                user = j.optString("user", d.user),
                pass = j.optString("pass", d.pass),
                tls = j.optBoolean("tls", d.tls),
                sni = j.optString("sni", d.sni),
                payload = j.optString("payload", d.payload),
                wsPath = j.optString("wsPath", d.wsPath),
                wsHost = j.optString("wsHost", d.wsHost),
                dnsResolver = j.optString("dnsResolver", d.dnsResolver),
                dnsDomain = j.optString("dnsDomain", d.dnsDomain),
                dnsPubKey = j.optString("dnsPubKey", d.dnsPubKey),
                link = j.optString("link", d.link)
            )
        }
    }
}

object Store {
    fun load(ctx: Context): Profile {
        val s = ctx.getSharedPreferences("isile", Context.MODE_PRIVATE).getString("profile", null)
        return if (s == null) Profile() else runCatching { Profile.fromJson(s) }.getOrDefault(Profile())
    }

    fun save(ctx: Context, p: Profile) {
        ctx.getSharedPreferences("isile", Context.MODE_PRIVATE).edit().putString("profile", p.toJson()).apply()
    }
}
