package com.tamaa.isilevpn

import android.content.ClipboardManager
import android.content.Context
import android.text.InputType
import android.view.Gravity
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ArrayAdapter
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.core.content.ContextCompat
import com.google.android.material.button.MaterialButton
import com.google.android.material.button.MaterialButtonToggleGroup
import com.google.android.material.materialswitch.MaterialSwitch
import com.google.android.material.textfield.MaterialAutoCompleteTextView
import com.google.android.material.textfield.TextInputEditText
import com.google.android.material.textfield.TextInputLayout

/** واجهة إعداد الكونفيج: نوع واحد من الخانات، وتظهر/تختفي حسب النوع والخيارات المفعّلة. */
class EditorPage(private val ctx: Context, private val root: LinearLayout) {
    var onApply: ((Profile) -> Unit)? = null

    private var cur = Profile()
    private var kind = Kind.SSH
    private val inf = LayoutInflater.from(ctx)
    private val MATCH = ViewGroup.LayoutParams.MATCH_PARENT
    private val WRAP = ViewGroup.LayoutParams.WRAP_CONTENT

    private fun dp(v: Int) = (v * ctx.resources.displayMetrics.density + 0.5f).toInt()

    class F(val til: TextInputLayout, val et: TextInputEditText)
    class D(val til: TextInputLayout, val actv: MaterialAutoCompleteTextView)

    private fun field(hint: String, password: Boolean = false, number: Boolean = false, multiline: Boolean = false): F {
        val til = inf.inflate(R.layout.field, root, false) as TextInputLayout
        val et = til.findViewById<TextInputEditText>(R.id.edit)
        til.hint = hint
        when {
            number -> et.inputType = InputType.TYPE_CLASS_NUMBER
            password -> {
                et.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
                til.endIconMode = TextInputLayout.END_ICON_PASSWORD_TOGGLE
            }
            multiline -> {
                et.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE or
                    InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS
                et.minLines = 3
                et.gravity = Gravity.TOP or Gravity.START
            }
            else -> et.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS
        }
        return F(til, et)
    }

    private fun dropdown(hint: String, items: List<String>): D {
        val til = inf.inflate(R.layout.dropdown, root, false) as TextInputLayout
        val a = til.findViewById<MaterialAutoCompleteTextView>(R.id.edit)
        til.hint = hint
        a.setAdapter(ArrayAdapter(ctx, android.R.layout.simple_dropdown_item_1line, items))
        return D(til, a)
    }

    private fun sw(label: String) = MaterialSwitch(ctx).apply {
        text = label
        textSize = 15f
        setPadding(dp(4), dp(6), dp(4), dp(6))
    }

    private fun section(title: String) = TextView(ctx).apply {
        text = title.uppercase()
        textSize = 12f
        setTextColor(ContextCompat.getColor(ctx, R.color.accent))
        typeface = android.graphics.Typeface.DEFAULT_BOLD
        letterSpacing = 0.08f
    }

    private fun row(a: View, b: View, bw: Int): LinearLayout {
        val r = LinearLayout(ctx).apply { orientation = LinearLayout.HORIZONTAL }
        r.addView(a, LinearLayout.LayoutParams(0, WRAP, 1f).apply { marginEnd = dp(8) })
        r.addView(b, LinearLayout.LayoutParams(dp(bw), WRAP))
        return r
    }

    // ---- العناصر (بترتيب ظهورها) ----
    private val heading = TextView(ctx).apply {
        textSize = 20f
        typeface = android.graphics.Typeface.DEFAULT_BOLD
    }
    private val kindGroup = MaterialButtonToggleGroup(ctx).apply {
        isSingleSelection = true
        isSelectionRequired = true
    }
    private val kindBtn = HashMap<Kind, Int>()
    private val btnPaste = MaterialButton(ctx, null, com.google.android.material.R.attr.materialButtonOutlinedStyle).apply {
        text = "Paste from clipboard"
        setIconResource(R.drawable.ic_paste)
    }
    private val fName = field("Config name")
    private val fHost = field("Server address")
    private val fPort = field("Port", number = true)
    private val rowHostPort = row(fHost.til, fPort.til, 110)
    private val fUser = field("Username")
    private val fPass = field("Password", password = true)
    private val fSecret = field("UUID")
    private val secPayload = section("Payload")
    private val swWs = sw("WebSocket")
    private val swPayload = sw("Enable payload")
    private val fPayload = field("Payload", multiline = true).also {
        it.til.helperText = "Tags: [crlf] [host] [port] [host_port]"
    }
    private val fProxy = field("Remote proxy")
    private val fProxyPort = field("Port", number = true)
    private val rowProxy = row(fProxy.til, fProxyPort.til, 110)
    private val fPath = field("Path")
    private val fWsHost = field("Host header")
    private val swTls = sw("TLS")
    private val fSni = field("SNI")
    private val dTlsVer = dropdown("SNI version", listOf("Auto", "TLSv1.0", "TLSv1.1", "TLSv1.2", "TLSv1.3"))
    private val dFp = dropdown(
        "Fingerprint",
        listOf("none", "chrome", "firefox", "safari", "ios", "android", "edge", "360", "qq", "random", "randomized")
    )
    private val fAlpn = field("ALPN (e.g. h2,http/1.1)")
    private val swInsecure = sw("Allow insecure")
    private val swMux = sw("Mux")
    private val btnApply = MaterialButton(ctx).apply {
        text = "Apply"
        textSize = 16f
        cornerRadius = dp(16)
    }

    init {
        root.removeAllViews()
        Kind.values().forEach { k ->
            val b = MaterialButton(ctx, null, com.google.android.material.R.attr.materialButtonOutlinedStyle)
            b.id = View.generateViewId()
            b.text = k.label
            b.textSize = 13f
            b.maxLines = 1
            b.setPadding(dp(2), 0, dp(2), 0)
            b.tag = k
            kindBtn[k] = b.id
            kindGroup.addView(b, LinearLayout.LayoutParams(0, dp(46), 1f))
        }
        listOf(
            heading, kindGroup, btnPaste, fName.til, rowHostPort, fUser.til, fPass.til, fSecret.til,
            secPayload, swWs, swPayload, fPayload.til, rowProxy, fPath.til, fWsHost.til,
            swTls, fSni.til, dTlsVer.til, dFp.til, fAlpn.til, swInsecure, swMux
        ).forEach { add(it) }
        root.addView(btnApply, LinearLayout.LayoutParams(MATCH, dp(56)).apply { topMargin = dp(8); bottomMargin = dp(32) })

        kindGroup.addOnButtonCheckedListener { g, id, checked ->
            if (checked) {
                kind = g.findViewById<View>(id).tag as Kind
                onKindChanged()
            }
        }
        val vis = { _: android.widget.CompoundButton, _: Boolean -> updateVisibility() }
        swWs.setOnCheckedChangeListener(vis)
        swPayload.setOnCheckedChangeListener(vis)
        swTls.setOnCheckedChangeListener(vis)
        btnPaste.setOnClickListener { pasteLink() }
        btnApply.setOnClickListener { apply() }
    }

    private fun add(v: View) {
        root.addView(v, LinearLayout.LayoutParams(MATCH, WRAP).apply {
            bottomMargin = dp(if (v === secPayload) 4 else 12)
            if (v === secPayload) topMargin = dp(8)
        })
    }

    private fun onKindChanged() {
        fSecret.til.hint = if (kind == Kind.TROJAN) "Password" else "UUID"
        val t = fPort.et.text.toString().trim()
        if (t.isEmpty() || t == "22" || t == "443") fPort.et.setText(if (kind.isSsh) "22" else "443")
        updateVisibility()
    }

    private fun show(v: View, on: Boolean) { v.visibility = if (on) View.VISIBLE else View.GONE }

    private fun updateVisibility() {
        val ssh = kind.isSsh
        val tls = swTls.isChecked
        show(btnPaste, true)
        show(fUser.til, ssh); show(fPass.til, ssh)
        show(fSecret.til, !ssh)
        show(secPayload, ssh)
        show(swPayload, ssh)
        show(fPayload.til, ssh && swPayload.isChecked)
        show(rowProxy, ssh)
        show(fPath.til, !ssh && swWs.isChecked)
        show(fWsHost.til, !ssh && swWs.isChecked)
        show(fSni.til, tls)
        show(dTlsVer.til, ssh && tls)
        show(dFp.til, !ssh && tls)
        show(fAlpn.til, !ssh && tls)
        show(swInsecure, tls)
        show(swMux, !ssh)
    }

    /** يملأ الواجهة من كونفيج موجود أو جديد. */
    fun bind(p: Profile, existing: Boolean) {
        heading.text = if (existing) "Edit config" else "New config"
        fill(p)
    }

    private fun fill(p: Profile) {
        cur = p.copy()
        kind = p.kind
        kindGroup.check(kindBtn[p.kind]!!)
        fSecret.til.hint = if (p.kind == Kind.TROJAN) "Password" else "UUID"
        fName.et.setText(p.name)
        fHost.et.setText(p.host)
        fPort.et.setText(p.port.toString())
        fUser.et.setText(p.user)
        fPass.et.setText(p.pass)
        fSecret.et.setText(p.secret)
        swWs.isChecked = p.ws
        swPayload.isChecked = p.payloadOn
        fPayload.et.setText(p.payload)
        fProxy.et.setText(p.proxyHost)
        fProxyPort.et.setText(p.proxyPort.toString())
        fPath.et.setText(p.wsPath)
        fWsHost.et.setText(p.wsHost)
        swTls.isChecked = p.tls
        fSni.et.setText(p.sni)
        dTlsVer.actv.setText(p.tlsVersion.ifEmpty { "Auto" }, false)
        dFp.actv.setText(p.fingerprint.ifEmpty { "none" }, false)
        fAlpn.et.setText(p.alpn)
        swInsecure.isChecked = p.insecure
        swMux.isChecked = p.mux
        listOf(fName, fHost, fPort, fUser, fPass, fSecret).forEach { it.til.error = null }
        updateVisibility()
    }

    private fun pasteLink() {
        val t = ctx.getSystemService(ClipboardManager::class.java)
            .primaryClip?.getItemAt(0)?.text?.toString().orEmpty()
        try {
            if (t.isBlank()) throw IllegalArgumentException("Clipboard is empty")
            val p = LinkParser.parse(t)
            if (p.name.isBlank()) p.name = fName.et.text.toString().trim()
            p.uid = cur.uid
            fill(p)
            Toast.makeText(ctx, "Config imported", Toast.LENGTH_SHORT).show()
        } catch (e: Exception) {
            Toast.makeText(ctx, e.message ?: "Invalid config", Toast.LENGTH_LONG).show()
        }
    }

    private fun txt(f: F) = f.et.text.toString().trim()

    private fun apply() {
        listOf(fName, fHost, fPort, fUser, fPass, fSecret).forEach { it.til.error = null }
        val host = txt(fHost)
        val port = txt(fPort).toIntOrNull()
        var bad: F? = null
        fun need(fail: Boolean, f: F, msg: String) {
            if (fail && bad == null) { f.til.error = msg; bad = f }
        }
        need(host.isEmpty(), fHost, "Required")
        need(port == null || port !in 1..65535, fPort, "1-65535")
        if (kind.isSsh) {
            need(txt(fUser).isEmpty(), fUser, "Required")
            need(fPass.et.text.isNullOrEmpty(), fPass, "Required")
        } else {
            need(txt(fSecret).isEmpty(), fSecret, "Required")
        }
        bad?.let { it.et.requestFocus(); return }

        val fp = dFp.actv.text.toString().trim().let { if (it == "none") "" else it }
        val p = cur.copy(
            kind = kind,
            name = txt(fName).ifEmpty { "${kind.label} $host" },
            host = host,
            port = port ?: 22,
            user = txt(fUser),
            pass = fPass.et.text.toString(),
            secret = txt(fSecret),
            ws = swWs.isChecked,
            payloadOn = swPayload.isChecked,
            payload = fPayload.et.text.toString().ifEmpty { DEFAULT_PAYLOAD },
            proxyHost = txt(fProxy),
            proxyPort = txt(fProxyPort).toIntOrNull()?.takeIf { it in 1..65535 } ?: 8080,
            wsPath = txt(fPath).ifEmpty { "/" },
            wsHost = txt(fWsHost),
            tls = swTls.isChecked,
            sni = txt(fSni),
            tlsVersion = dTlsVer.actv.text.toString().ifEmpty { "Auto" },
            fingerprint = fp,
            alpn = txt(fAlpn),
            insecure = swInsecure.isChecked,
            mux = swMux.isChecked
        )
        onApply?.invoke(p)
    }
}
