package com.tamaa.isilevpn

import android.Manifest
import android.app.Activity
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.content.res.ColorStateList
import android.graphics.Typeface
import android.net.ConnectivityManager
import android.net.LinkProperties
import android.net.Network
import android.net.NetworkRequest
import android.net.Uri
import android.net.VpnService
import android.os.Build
import android.os.Bundle
import android.text.SpannableStringBuilder
import android.text.Spanned
import android.text.style.ForegroundColorSpan
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.InputMethodManager
import android.widget.LinearLayout
import android.widget.RadioButton
import android.widget.RadioGroup
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import androidx.core.view.GravityCompat
import androidx.drawerlayout.widget.DrawerLayout
import androidx.viewpager.widget.PagerAdapter
import androidx.viewpager.widget.ViewPager
import com.google.android.material.button.MaterialButton
import com.google.android.material.button.MaterialButtonToggleGroup
import com.google.android.material.card.MaterialCardView
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.google.android.material.materialswitch.MaterialSwitch
import java.io.File
import java.util.Locale

class MainActivity : AppCompatActivity() {
    /** MAIN = ViewPager فيه صفحتان: الرئيسية (0) والسجل (1). */
    private enum class Page { MAIN, EDITOR, LIST }

    private lateinit var drawer: DrawerLayout
    private lateinit var pager: ViewPager
    private lateinit var homeView: View
    private lateinit var logsView: View
    private lateinit var pageEditor: ScrollView
    private lateinit var pageList: View
    private lateinit var listRoot: LinearLayout
    private lateinit var editor: EditorPage

    private lateinit var tvState: TextView
    private lateinit var dot: View
    private lateinit var tvIp: TextView
    private lateinit var tvIpVpn: TextView
    private lateinit var tvError: TextView
    private lateinit var tvDown: TextView
    private lateinit var tvUp: TextView
    private lateinit var graph: SpeedGraph
    private lateinit var btn: MaterialButton
    private lateinit var tvActiveName: TextView
    private lateinit var tvActiveType: TextView
    private lateinit var tvActiveAddr: TextView

    private lateinit var logScroll: ScrollView
    private lateinit var tvLogs: TextView
    private var appTab = false
    private var shownVersion = -1
    private var shownAppTab = false

    private var page = Page.MAIN

    private val vpnPrompt = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
        if (r.resultCode == Activity.RESULT_OK) startVpn() else Bus.log("ERROR: VPN permission denied")
    }
    private val notifPerm = registerForActivityResult(ActivityResultContracts.RequestPermission()) { }
    private val pickIsl = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) importIslUri(uri)
    }

    private fun <T : View> f(id: Int): T = findViewById(id)
    private fun dp(v: Int) = (v * resources.displayMetrics.density + 0.5f).toInt()
    private fun col(id: Int) = ContextCompat.getColor(this, id)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        drawer = f(R.id.drawer)
        pageEditor = f(R.id.pageEditor)
        pageList = f(R.id.pageList)
        listRoot = f(R.id.listRoot)

        // الرئيسية والسجل: قطعتان متجاورتان تتبدلان بالتمرير مع الإصبع
        homeView = layoutInflater.inflate(R.layout.page_home, null)
        logsView = layoutInflater.inflate(R.layout.page_logs, null)
        pager = f(R.id.pager)
        pager.offscreenPageLimit = 2
        pager.adapter = object : PagerAdapter() {
            private val views = listOf(homeView, logsView)
            override fun getCount() = views.size
            override fun isViewFromObject(view: View, obj: Any) = view === obj
            override fun instantiateItem(container: ViewGroup, position: Int): Any {
                val v = views[position]
                if (v.parent == null) container.addView(v)
                return v
            }
            override fun destroyItem(container: ViewGroup, position: Int, obj: Any) {
                container.removeView(obj as View)
            }
        }
        pager.addOnPageChangeListener(object : ViewPager.SimpleOnPageChangeListener() {
            override fun onPageSelected(position: Int) {
                if (position == 1) renderLogs(true)
            }
        })

        tvState = homeView.findViewById(R.id.tvState); dot = homeView.findViewById(R.id.dot)
        tvIp = homeView.findViewById(R.id.tvIp); tvIpVpn = homeView.findViewById(R.id.tvIpVpn); tvError = homeView.findViewById(R.id.tvError)
        tvDown = homeView.findViewById(R.id.tvDown); tvUp = homeView.findViewById(R.id.tvUp)
        graph = homeView.findViewById(R.id.graph); btn = homeView.findViewById(R.id.btnConnect)
        tvActiveName = homeView.findViewById(R.id.tvActiveName)
        tvActiveType = homeView.findViewById(R.id.tvActiveType)
        tvActiveAddr = homeView.findViewById(R.id.tvActiveAddr)
        logScroll = logsView.findViewById(R.id.logScroll)
        tvLogs = logsView.findViewById(R.id.tvLogs)

        editor = EditorPage(this, f(R.id.editorRoot))
        editor.onApply = { p -> applyProfile(p) }

        f<View>(R.id.btnMenu).setOnClickListener { drawer.openDrawer(GravityCompat.START) }
        f<View>(R.id.btnCreate).setOnClickListener { openEditor(null) }
        f<View>(R.id.btnConfigs).setOnClickListener { showPage(Page.LIST) }
        homeView.findViewById<View>(R.id.cardActive).setOnClickListener { showPage(Page.LIST) }
        f<View>(R.id.menuLogs).setOnClickListener { drawer.closeDrawers(); showLogs() }
        val ver = try { packageManager.getPackageInfo(packageName, 0).versionName } catch (_: Exception) { "" }
        f<TextView>(R.id.menuVersion).text = "Version $ver"
        btn.setOnClickListener { onConnectClick() }

        val tabs = logsView.findViewById<MaterialButtonToggleGroup>(R.id.logTabs)
        tabs.check(R.id.tabConn)
        tabs.addOnButtonCheckedListener { _, id, checked ->
            if (checked) {
                appTab = id == R.id.tabApp
                renderLogs(true)
            }
        }
        logsView.findViewById<View>(R.id.btnLogClear).setOnClickListener { Bus.clear(appTab) }
        logsView.findViewById<View>(R.id.btnLogCopy).setOnClickListener {
            getSystemService(ClipboardManager::class.java)
                .setPrimaryClip(ClipData.newPlainText("log", buildLogs(appTab).toString()))
            Toast.makeText(this, "Logs copied", Toast.LENGTH_SHORT).show()
        }

        // القائمة الجانبية حرة: تُفتح بالزر أو بالسحب من حافة اليسار، وتُغلق بتمريرها لليسار
        drawer.setDrawerLockMode(DrawerLayout.LOCK_MODE_UNLOCKED)
        widenDrawerEdge()

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                when {
                    drawer.isDrawerOpen(GravityCompat.START) -> drawer.closeDrawer(GravityCompat.START)
                    page != Page.MAIN -> showPage(Page.MAIN)
                    pager.currentItem == 1 -> pager.setCurrentItem(0, true)
                    else -> {
                        isEnabled = false
                        onBackPressedDispatcher.onBackPressed()
                        isEnabled = true
                    }
                }
            }
        })
        showPage(Page.MAIN)
        handleIncoming(intent)
    }

    /** يوسّع منطقة السحب من حافة اليسار (الافتراضي ضيق جدًا) كي يسهل فتح القائمة. */
    private fun widenDrawerEdge() {
        try {
            val f = DrawerLayout::class.java.getDeclaredField("mLeftDragger")
            f.isAccessible = true
            val dragger = f.get(drawer)
            val e = dragger.javaClass.getDeclaredField("mEdgeSize")
            e.isAccessible = true
            e.setInt(dragger, dp(32))
        } catch (_: Throwable) {
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        handleIncoming(intent)
    }

    private fun handleIncoming(i: Intent?) {
        if (i == null || i.action != Intent.ACTION_VIEW) return
        val data = i.data ?: return
        i.data = null // لا نعيد الاستيراد عند تدوير الشاشة
        importIslUri(data)
    }

    override fun onResume() {
        super.onResume()
        Bus.listener = { runOnUiThread { refresh() } }
        watchNetwork()
        refreshActive()
        refresh()
    }

    override fun onPause() {
        unwatchNetwork()
        Bus.listener = null
        super.onPause()
    }

    // ---------- مراقبة تغيّر الشبكة (لتحديث عنوان IP) ----------
    private var netCb: ConnectivityManager.NetworkCallback? = null

    private fun watchNetwork() {
        if (netCb != null) return
        val cb = object : ConnectivityManager.NetworkCallback() {
            private fun upd() {
                runOnUiThread {
                    refresh()
                    tvIp.postDelayed({ refresh() }, 600)
                }
            }
            override fun onAvailable(network: Network) = upd()
            override fun onLost(network: Network) = upd()
            override fun onLinkPropertiesChanged(network: Network, lp: LinkProperties) = upd()
        }
        try {
            getSystemService(ConnectivityManager::class.java)
                .registerNetworkCallback(NetworkRequest.Builder().build(), cb)
            netCb = cb
        } catch (_: Exception) {
        }
    }

    private fun unwatchNetwork() {
        val cb = netCb ?: return
        netCb = null
        try { getSystemService(ConnectivityManager::class.java).unregisterNetworkCallback(cb) } catch (_: Exception) {}
    }

    // ---------- الاتصال ----------
    private fun onConnectClick() {
        if (Bus.state != State.IDLE) {
            startService(Intent(this, IsileVpnService::class.java).setAction(IsileVpnService.ACTION_STOP))
            return
        }
        if (Store.active(this) == null) {
            Toast.makeText(this, "Create a config first", Toast.LENGTH_SHORT).show()
            openEditor(null)
            return
        }
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) notifPerm.launch(Manifest.permission.POST_NOTIFICATIONS)
        val i = VpnService.prepare(this)
        if (i != null) vpnPrompt.launch(i) else startVpn()
    }

    private fun startVpn() {
        ContextCompat.startForegroundService(
            this, Intent(this, IsileVpnService::class.java).setAction(IsileVpnService.ACTION_START)
        )
    }

    // ---------- الصفحات ----------
    private fun showPage(p: Page) {
        page = p
        pager.visibility = if (p == Page.MAIN) View.VISIBLE else View.GONE
        pageEditor.visibility = if (p == Page.EDITOR) View.VISIBLE else View.GONE
        pageList.visibility = if (p == Page.LIST) View.VISIBLE else View.GONE
        if (p == Page.LIST) buildList()
        if (p == Page.MAIN) refreshActive()
        refresh()
    }

    private fun showLogs() {
        showPage(Page.MAIN)
        pager.setCurrentItem(1, true)
        renderLogs(true)
    }

    private fun openEditor(p: Profile?) {
        if (p?.locked == true) { Toast.makeText(this, "This config is locked", Toast.LENGTH_SHORT).show(); return }
        editor.bind(p?.copy() ?: Profile(), p != null)
        pageEditor.scrollTo(0, 0)
        showPage(Page.EDITOR)
    }

    private fun applyProfile(p: Profile) {
        val prev = Store.activeId(this)
        Store.upsert(this, p)
        if (Bus.state == State.IDLE || prev == null || prev == p.uid) {
            Store.setActive(this, p.uid)
        } else {
            Toast.makeText(this, "Saved. Disconnect to switch to it.", Toast.LENGTH_LONG).show()
        }
        val im = getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
        im.hideSoftInputFromWindow(pageEditor.windowToken, 0)
        showPage(Page.MAIN)
        pager.setCurrentItem(0, false)
    }

    // ---------- الشاشة الرئيسية ----------
    private fun refresh() {
        val st = Bus.state
        tvState.text = when (st) {
            State.IDLE -> "Disconnected"
            State.CONNECTING -> "Connecting..."
            State.CONNECTED -> "Connected"
        }
        dot.backgroundTintList = ColorStateList.valueOf(
            col(when (st) { State.IDLE -> R.color.text_dim; State.CONNECTING -> R.color.amber; State.CONNECTED -> R.color.green })
        )
        // الأعلى: IP الهاتف الحقيقي دائمًا. تحته: IP الاتصال الجديد (عند الاتصال فقط). أرقام فقط دون تسمية.
        tvIp.text = LocalIp.get(this).ifEmpty { "—" }
        if (st == State.CONNECTED) {
            tvIpVpn.visibility = View.VISIBLE
            tvIpVpn.text = Bus.ip.ifEmpty { "..." }
        } else {
            tvIpVpn.visibility = View.GONE
        }
        val err = Bus.lastError
        tvError.visibility = if (st == State.IDLE && err.isNotEmpty()) View.VISIBLE else View.GONE
        tvError.text = err
        tvDown.text = fmtSpeed(Bus.curDown)
        tvUp.text = fmtSpeed(Bus.curUp)
        val (d, u) = Bus.history()
        graph.set(d, u)
        btn.text = if (st == State.IDLE) "Connect" else "Disconnect"
        btn.backgroundTintList = ColorStateList.valueOf(
            col(when (st) { State.IDLE -> R.color.accent; State.CONNECTING -> R.color.amber; State.CONNECTED -> R.color.red })
        )
        if (page == Page.MAIN && pager.currentItem == 1) renderLogs(false)
    }

    private fun refreshActive() {
        val a = Store.active(this)
        if (a == null) {
            tvActiveName.text = "No config selected"
            tvActiveType.visibility = View.GONE
            tvActiveAddr.text = "Tap + to create one"
        } else {
            tvActiveName.text = a.name
            tvActiveType.visibility = View.VISIBLE
            tvActiveType.text = a.typeLine()
            tvActiveAddr.text = if (a.locked) "Locked config" else "${a.host}:${a.port}"
        }
    }

    private fun fmtSpeed(b: Long): String = when {
        b < 1024 -> "$b B/s"
        b < 1024 * 1024 -> String.format(Locale.US, "%.1f KB/s", b / 1024.0)
        else -> String.format(Locale.US, "%.2f MB/s", b / 1048576.0)
    }

    // ---------- قائمة الكونفيجات ----------
    private fun buildList() {
        listRoot.removeAllViews()
        val head = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = android.view.Gravity.CENTER_VERTICAL
            setPadding(0, 0, 0, dp(14))
        }
        head.addView(TextView(this).apply {
            text = "Saved configs"
            textSize = 20f
            typeface = Typeface.DEFAULT_BOLD
        }, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        head.addView(MaterialButton(this, null, com.google.android.material.R.attr.materialButtonOutlinedStyle).apply {
            text = "Import"
            setOnClickListener { showImportDialog() }
        })
        listRoot.addView(head)
        val items = Store.all(this)
        val act = Store.activeId(this)
        if (items.isEmpty()) {
            listRoot.addView(TextView(this).apply {
                text = "No saved configs yet. Tap + to create one, or Import."
                setTextColor(col(R.color.text_dim))
            })
            return
        }
        for (p in items) {
            val v = layoutInflater.inflate(R.layout.item_config, listRoot, false) as MaterialCardView
            v.findViewById<TextView>(R.id.itName).text = p.name
            v.findViewById<TextView>(R.id.itSub).text =
                if (p.locked) "${p.kind.label}  ·  Locked" else "${p.typeLine()}  ·  ${p.host}:${p.port}"
            v.strokeColor = col(R.color.accent)
            v.strokeWidth = if (p.uid == act) dp(2) else 0
            v.setOnClickListener { select(p) }
            val edit = v.findViewById<View>(R.id.btnEdit)
            val share = v.findViewById<View>(R.id.btnShare)
            if (p.locked) {
                edit.visibility = View.GONE
                share.visibility = View.GONE
            } else {
                edit.setOnClickListener { openEditor(p) }
                share.setOnClickListener { showShareDialog(p) }
            }
            v.findViewById<View>(R.id.btnDelete).setOnClickListener { confirmDelete(p) }
            listRoot.addView(v)
        }
    }

    // ---------- المشاركة ----------
    private fun showShareDialog(p: Profile) {
        if (p.locked) return
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(8), dp(20), 0)
        }
        val rg = RadioGroup(this)
        val rFile = RadioButton(this).apply { id = View.generateViewId(); text = "Share as file (.isl)" }
        val rLink = RadioButton(this).apply { id = View.generateViewId(); text = "Share as link" }
        val rCopy = RadioButton(this).apply { id = View.generateViewId(); text = "Copy link" }
        listOf(rFile, rLink, rCopy).forEach { rg.addView(it) }
        rFile.isChecked = true
        val swLock = MaterialSwitch(this).apply {
            text = "Lock config"
            isChecked = false
            setPadding(dp(4), dp(10), dp(4), dp(2))
        }
        val hint = TextView(this).apply {
            textSize = 12f
            setTextColor(col(R.color.text_dim))
        }
        fun upd() {
            val file = rFile.isChecked
            swLock.visibility = if (file) View.VISIBLE else View.GONE
            hint.text = when {
                !file -> "The link shows all details and can be opened by any compatible app."
                swLock.isChecked -> "Locked: the receiver can connect but cannot view, edit or share it."
                else -> "Open: the receiver can view, edit and share it."
            }
        }
        rg.setOnCheckedChangeListener { _, _ -> upd() }
        swLock.setOnCheckedChangeListener { _, _ -> upd() }
        upd()
        box.addView(rg); box.addView(swLock); box.addView(hint)
        MaterialAlertDialogBuilder(this)
            .setTitle("Share \"${p.name}\"")
            .setView(box)
            .setPositiveButton("Continue") { _, _ ->
                try {
                    when {
                        rFile.isChecked -> shareFile(p, swLock.isChecked)
                        rLink.isChecked -> {
                            startActivity(Intent.createChooser(
                                Intent(Intent.ACTION_SEND).setType("text/plain")
                                    .putExtra(Intent.EXTRA_TEXT, LinkGen.make(p)), "Share link"))
                        }
                        else -> {
                            getSystemService(ClipboardManager::class.java)
                                .setPrimaryClip(ClipData.newPlainText("config", LinkGen.make(p)))
                            Toast.makeText(this, "Link copied", Toast.LENGTH_SHORT).show()
                        }
                    }
                } catch (e: Exception) {
                    Toast.makeText(this, "Share failed: ${e.message}", Toast.LENGTH_LONG).show()
                }
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun shareFile(p: Profile, lock: Boolean) {
        val dir = File(cacheDir, "share").apply { mkdirs() }
        dir.listFiles()?.forEach { it.delete() }
        val base = p.name.replace(Regex("[^\\p{L}\\p{N} _.-]"), "").trim().ifEmpty { "config" }
        val f = File(dir, "$base.${IslFile.EXT}")
        f.writeBytes(IslFile.encode(p, lock))
        val uri = FileProvider.getUriForFile(this, "$packageName.files", f)
        val send = Intent(Intent.ACTION_SEND)
            .setType(IslFile.MIME)
            .putExtra(Intent.EXTRA_STREAM, uri)
            .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        startActivity(Intent.createChooser(send, "Share config"))
    }

    // ---------- الاستيراد ----------
    private fun showImportDialog() {
        MaterialAlertDialogBuilder(this)
            .setTitle("Import config")
            .setItems(arrayOf("From file (.isl)", "From clipboard (link)")) { _, which ->
                if (which == 0) pickIsl.launch(arrayOf("*/*")) else importClipboard()
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun addImported(p: Profile) {
        p.uid = java.util.UUID.randomUUID().toString()
        if (p.name.isBlank()) p.name = "${p.kind.label} ${if (p.locked) "config" else p.host}"
        Store.upsert(this, p)
        if (Store.activeId(this) == null) Store.setActive(this, p.uid)
        Toast.makeText(this, "Imported: ${p.name}" + if (p.locked) " (locked)" else "", Toast.LENGTH_LONG).show()
        showPage(Page.LIST)
    }

    private fun importClipboard() {
        val t = getSystemService(ClipboardManager::class.java)
            .primaryClip?.getItemAt(0)?.text?.toString().orEmpty()
        try {
            if (t.isBlank()) throw IllegalArgumentException("Clipboard is empty")
            addImported(LinkParser.parse(t))
        } catch (e: Exception) {
            Toast.makeText(this, e.message ?: "Invalid config", Toast.LENGTH_LONG).show()
        }
    }

    private fun importIslUri(uri: Uri) {
        try {
            val bytes = contentResolver.openInputStream(uri)?.use { it.readBytes() }
                ?: throw IllegalArgumentException("Cannot read file")
            if (bytes.size > 1_000_000) throw IllegalArgumentException("File too large")
            addImported(IslFile.decode(bytes))
        } catch (e: Exception) {
            Toast.makeText(this, e.message ?: "Import failed", Toast.LENGTH_LONG).show()
        }
    }

    private fun select(p: Profile) {
        if (Bus.state != State.IDLE && p.uid != Store.activeId(this)) {
            Toast.makeText(this, "Disconnect first to switch config", Toast.LENGTH_SHORT).show()
            return
        }
        Store.setActive(this, p.uid)
        showPage(Page.MAIN)
        pager.setCurrentItem(0, false)
    }

    private fun confirmDelete(p: Profile) {
        if (Bus.state != State.IDLE && p.uid == Store.activeId(this)) {
            Toast.makeText(this, "Disconnect first", Toast.LENGTH_SHORT).show()
            return
        }
        MaterialAlertDialogBuilder(this)
            .setTitle("Delete config")
            .setMessage("Delete \"${p.name}\"?")
            .setPositiveButton("Delete") { _, _ ->
                Store.delete(this, p.uid)
                buildList()
                refreshActive()
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    // ---------- السجلات ----------
    private fun renderLogs(force: Boolean) {
        if (!force && Bus.logVersion == shownVersion && shownAppTab == appTab) return
        shownVersion = Bus.logVersion
        shownAppTab = appTab
        val child = logScroll.getChildAt(0)
        val atBottom = force || child == null ||
            child.bottom - (logScroll.height + logScroll.scrollY) < dp(80)
        tvLogs.text = buildLogs(appTab)
        if (atBottom) logScroll.post { logScroll.fullScroll(View.FOCUS_DOWN) }
    }

    private fun buildLogs(forApp: Boolean): SpannableStringBuilder {
        val dim = col(R.color.text_dim)
        val sb = SpannableStringBuilder()
        fun put(t: String, c: Int) {
            val a = sb.length
            sb.append(t)
            sb.setSpan(ForegroundColorSpan(c), a, sb.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
        }
        val text = Bus.text(forApp)
        if (text.isEmpty()) {
            put(
                if (forApp) "No app logs yet." else "No logs yet. Connect to see each step here.",
                dim
            )
            return sb
        }
        for (line in text.lineSequence()) {
            if (line.isBlank()) continue
            if (line.length > 10 && line[2] == ':' && line[5] == ':') {
                put(line.substring(0, 8), dim)
                val m = line.substring(8).trimStart()
                put("  ", dim)
                if (m.startsWith("Server:")) {
                    // رسالة الخادم: سجل واحد متعدد الأسطر، ألوانها بوسوم HTML (أو ANSI)
                    put("Server:", dim)
                    val body = m.removePrefix("Server:").trimStart().replace(Bus.NL, '\n')
                    sb.append('\n')
                    if (Ansi.hasHtml(body)) Ansi.appendHtml(sb, body)
                    else Ansi.append(sb, body, col(R.color.text))
                } else {
                    Ansi.append(sb, m, col(logColor(Ansi.strip(m))))
                }
            } else {
                put(line, dim)
            }
            sb.append('\n')
        }
        return sb
    }

    private fun logColor(m: String): Int {
        val l = m.lowercase(Locale.US)
        return when {
            m.startsWith("ERROR") || l.contains("failed") || l.contains("rejected") ||
                l.contains("lost") || l.contains("unexpectedly") || l.contains("denied") ||
                l.contains("[error]") -> R.color.red
            m.startsWith("Disconnect") || l.contains("not supported") || l.contains("no sni") ||
                l.contains("[warning]") -> R.color.amber
            m == "Connected" || l.contains("authenticated") || l.contains("connected successfully") ||
                l.contains("handshake ok") || l.contains("started") || l.startsWith("public ip") ||
                l.startsWith("http/") -> R.color.green
            else -> R.color.text
        }
    }
}
