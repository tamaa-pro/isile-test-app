package com.tamaa.isilevpn

import android.Manifest
import android.app.Activity
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.content.res.ColorStateList
import android.graphics.Typeface
import android.net.VpnService
import android.os.Build
import android.os.Bundle
import android.view.View
import android.view.inputmethod.InputMethodManager
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.core.view.GravityCompat
import androidx.drawerlayout.widget.DrawerLayout
import com.google.android.material.button.MaterialButton
import com.google.android.material.card.MaterialCardView
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import java.util.Locale

class MainActivity : AppCompatActivity() {
    private enum class Page { HOME, EDITOR, LIST }

    private lateinit var drawer: DrawerLayout
    private lateinit var pageHome: View
    private lateinit var pageEditor: ScrollView
    private lateinit var pageList: View
    private lateinit var listRoot: LinearLayout
    private lateinit var editor: EditorPage
    private lateinit var tvState: TextView
    private lateinit var dot: View
    private lateinit var tvIp: TextView
    private lateinit var tvError: TextView
    private lateinit var tvDown: TextView
    private lateinit var tvUp: TextView
    private lateinit var graph: SpeedGraph
    private lateinit var btn: MaterialButton
    private lateinit var tvActiveName: TextView
    private lateinit var tvActiveType: TextView
    private lateinit var tvActiveAddr: TextView
    private var page = Page.HOME

    private val vpnPrompt = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
        if (r.resultCode == Activity.RESULT_OK) startVpn() else Bus.log("ERROR: VPN permission denied")
    }
    private val notifPerm = registerForActivityResult(ActivityResultContracts.RequestPermission()) { }

    private fun <T : View> f(id: Int): T = findViewById(id)
    private fun dp(v: Int) = (v * resources.displayMetrics.density + 0.5f).toInt()
    private fun col(id: Int) = ContextCompat.getColor(this, id)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        drawer = f(R.id.drawer)
        pageHome = f(R.id.pageHome)
        pageEditor = f(R.id.pageEditor)
        pageList = f(R.id.pageList)
        listRoot = f(R.id.listRoot)
        tvState = f(R.id.tvState); dot = f(R.id.dot); tvIp = f(R.id.tvIp); tvError = f(R.id.tvError)
        tvDown = f(R.id.tvDown); tvUp = f(R.id.tvUp); graph = f(R.id.graph); btn = f(R.id.btnConnect)
        tvActiveName = f(R.id.tvActiveName); tvActiveType = f(R.id.tvActiveType); tvActiveAddr = f(R.id.tvActiveAddr)

        editor = EditorPage(this, f(R.id.editorRoot))
        editor.onApply = { p -> applyProfile(p) }

        f<View>(R.id.btnMenu).setOnClickListener { drawer.openDrawer(GravityCompat.END) }
        f<View>(R.id.btnCreate).setOnClickListener { openEditor(null) }
        f<View>(R.id.btnConfigs).setOnClickListener { showPage(Page.LIST) }
        f<View>(R.id.cardActive).setOnClickListener { showPage(Page.LIST) }
        f<View>(R.id.menuLogs).setOnClickListener { drawer.closeDrawers(); showLogs() }
        f<View>(R.id.menuAbout).setOnClickListener { drawer.closeDrawers(); showAbout() }
        btn.setOnClickListener { onConnectClick() }

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                when {
                    drawer.isDrawerOpen(GravityCompat.END) -> drawer.closeDrawer(GravityCompat.END)
                    page != Page.HOME -> showPage(Page.HOME)
                    else -> {
                        isEnabled = false
                        onBackPressedDispatcher.onBackPressed()
                        isEnabled = true
                    }
                }
            }
        })
        showPage(Page.HOME)
    }

    override fun onResume() {
        super.onResume()
        Bus.listener = { runOnUiThread { refresh() } }
        refreshActive()
        refresh()
    }

    override fun onPause() {
        Bus.listener = null
        super.onPause()
    }

    // ---------- الاتصال ----------
    private fun onConnectClick() {
        if (Bus.state != State.IDLE) {
            startService(Intent(this, IsileVpnService::class.java).setAction(IsileVpnService.ACTION_STOP))
            return
        }
        if (Store.active(this) == null) {
            Toast.makeText(this, "Create a config first", Toast.LENGTH_SHORT).show()
            openEditor(null)
            return
        }
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) notifPerm.launch(Manifest.permission.POST_NOTIFICATIONS)
        val i = VpnService.prepare(this)
        if (i != null) vpnPrompt.launch(i) else startVpn()
    }

    private fun startVpn() {
        ContextCompat.startForegroundService(
            this, Intent(this, IsileVpnService::class.java).setAction(IsileVpnService.ACTION_START)
        )
    }

    // ---------- الصفحات ----------
    private fun showPage(p: Page) {
        page = p
        pageHome.visibility = if (p == Page.HOME) View.VISIBLE else View.GONE
        pageEditor.visibility = if (p == Page.EDITOR) View.VISIBLE else View.GONE
        pageList.visibility = if (p == Page.LIST) View.VISIBLE else View.GONE
        if (p == Page.LIST) buildList()
        if (p == Page.HOME) refreshActive()
        refresh()
    }

    private fun openEditor(p: Profile?) {
        editor.bind(p?.copy() ?: Profile(), p != null)
        pageEditor.scrollTo(0, 0)
        showPage(Page.EDITOR)
    }

    private fun applyProfile(p: Profile) {
        val prev = Store.activeId(this)
        Store.upsert(this, p)
        if (Bus.state == State.IDLE || prev == null || prev == p.uid) {
            Store.setActive(this, p.uid)
        } else {
            Toast.makeText(this, "Saved. Disconnect to switch to it.", Toast.LENGTH_LONG).show()
        }
        val im = getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
        im.hideSoftInputFromWindow(pageEditor.windowToken, 0)
        showPage(Page.HOME)
    }

    // ---------- الشاشة الرئيسية ----------
    private fun refresh() {
        val st = Bus.state
        tvState.text = when (st) {
            State.IDLE -> "Disconnected"
            State.CONNECTING -> "Connecting..."
            State.CONNECTED -> "Connected"
        }
        dot.backgroundTintList = ColorStateList.valueOf(
            col(when (st) { State.IDLE -> R.color.text_dim; State.CONNECTING -> R.color.amber; State.CONNECTED -> R.color.green })
        )
        tvIp.text = when {
            st != State.CONNECTED -> "IP: —"
            Bus.ip.isEmpty() -> "IP: ..."
            else -> "IP: ${Bus.ip}"
        }
        val err = Bus.lastError
        tvError.visibility = if (st == State.IDLE && err.isNotEmpty()) View.VISIBLE else View.GONE
        tvError.text = err
        tvDown.text = fmtSpeed(Bus.curDown)
        tvUp.text = fmtSpeed(Bus.curUp)
        val (d, u) = Bus.history()
        graph.set(d, u)
        btn.text = if (st == State.IDLE) "Connect" else "Disconnect"
        btn.backgroundTintList = ColorStateList.valueOf(
            col(when (st) { State.IDLE -> R.color.accent; State.CONNECTING -> R.color.amber; State.CONNECTED -> R.color.red })
        )
    }

    private fun refreshActive() {
        val a = Store.active(this)
        if (a == null) {
            tvActiveName.text = "No config selected"
            tvActiveType.visibility = View.GONE
            tvActiveAddr.text = "Tap + to create one"
        } else {
            tvActiveName.text = a.name
            tvActiveType.visibility = View.VISIBLE
            tvActiveType.text = a.typeLine()
            tvActiveAddr.text = "${a.host}:${a.port}"
        }
    }

    private fun fmtSpeed(b: Long): String = when {
        b < 1024 -> "$b B/s"
        b < 1024 * 1024 -> String.format(Locale.US, "%.1f KB/s", b / 1024.0)
        else -> String.format(Locale.US, "%.2f MB/s", b / 1048576.0)
    }

    // ---------- قائمة الكونفيجات ----------
    private fun buildList() {
        listRoot.removeAllViews()
        listRoot.addView(TextView(this).apply {
            text = "Saved configs"
            textSize = 20f
            typeface = Typeface.DEFAULT_BOLD
            setPadding(0, 0, 0, dp(14))
        })
        val items = Store.all(this)
        val act = Store.activeId(this)
        if (items.isEmpty()) {
            listRoot.addView(TextView(this).apply {
                text = "No saved configs yet. Tap + to create one."
                setTextColor(col(R.color.text_dim))
            })
            return
        }
        for (p in items) {
            val v = layoutInflater.inflate(R.layout.item_config, listRoot, false) as MaterialCardView
            v.findViewById<TextView>(R.id.itName).text = p.name
            v.findViewById<TextView>(R.id.itSub).text = "${p.typeLine()}  ·  ${p.host}:${p.port}"
            v.strokeColor = col(R.color.accent)
            v.strokeWidth = if (p.uid == act) dp(2) else 0
            v.setOnClickListener { select(p) }
            v.findViewById<View>(R.id.btnEdit).setOnClickListener { openEditor(p) }
            v.findViewById<View>(R.id.btnDelete).setOnClickListener { confirmDelete(p) }
            listRoot.addView(v)
        }
    }

    private fun select(p: Profile) {
        if (Bus.state != State.IDLE && p.uid != Store.activeId(this)) {
            Toast.makeText(this, "Disconnect first to switch config", Toast.LENGTH_SHORT).show()
            return
        }
        Store.setActive(this, p.uid)
        showPage(Page.HOME)
    }

    private fun confirmDelete(p: Profile) {
        if (Bus.state != State.IDLE && p.uid == Store.activeId(this)) {
            Toast.makeText(this, "Disconnect first", Toast.LENGTH_SHORT).show()
            return
        }
        MaterialAlertDialogBuilder(this)
            .setTitle("Delete config")
            .setMessage("Delete \"${p.name}\"?")
            .setPositiveButton("Delete") { _, _ ->
                Store.delete(this, p.uid)
                buildList()
                refreshActive()
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    // ---------- القائمة الجانبية ----------
    private fun showLogs() {
        val tv = TextView(this).apply {
            text = Bus.text().ifEmpty { "(empty)" }
            typeface = Typeface.MONOSPACE
            textSize = 11f
            setTextIsSelectable(true)
            setPadding(dp(20), dp(12), dp(20), dp(12))
        }
        MaterialAlertDialogBuilder(this)
            .setTitle("Logs")
            .setView(ScrollView(this).apply { addView(tv) })
            .setPositiveButton("Close", null)
            .setNeutralButton("Copy") { _, _ ->
                getSystemService(ClipboardManager::class.java).setPrimaryClip(ClipData.newPlainText("log", Bus.text()))
            }
            .show()
    }

    private fun showAbout() {
        MaterialAlertDialogBuilder(this)
            .setTitle("Isile VPN")
            .setMessage("Version 0.2.0\nSSH · VLESS · VMess · Trojan")
            .setPositiveButton("OK", null)
            .show()
    }
}
