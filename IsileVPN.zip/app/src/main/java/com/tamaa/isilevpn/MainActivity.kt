package com.tamaa.isilevpn

import android.Manifest
import android.app.Activity
import android.content.ClipboardManager
import android.content.Intent
import android.content.pm.PackageManager
import android.net.VpnService
import android.os.Build
import android.os.Bundle
import android.view.View
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.CheckBox
import android.widget.EditText
import android.widget.Spinner
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat

class MainActivity : AppCompatActivity() {
    private lateinit var sp: Spinner
    private lateinit var etHost: EditText
    private lateinit var etPort: EditText
    private lateinit var etUser: EditText
    private lateinit var etPass: EditText
    private lateinit var cbTls: CheckBox
    private lateinit var etSni: EditText
    private lateinit var etPayload: EditText
    private lateinit var etWsPath: EditText
    private lateinit var etWsHost: EditText
    private lateinit var etDnsResolver: EditText
    private lateinit var etDnsDomain: EditText
    private lateinit var etDnsKey: EditText
    private lateinit var etLink: EditText
    private lateinit var btn: Button
    private lateinit var tvStatus: TextView
    private lateinit var tvLog: TextView

    private val vpnPrompt = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
        if (r.resultCode == Activity.RESULT_OK) startVpn() else Bus.log("VPN permission denied")
    }
    private val notifPerm = registerForActivityResult(ActivityResultContracts.RequestPermission()) { }

    private fun <T : View> f(id: Int): T = findViewById(id)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        sp = f(R.id.spMode); etHost = f(R.id.etHost); etPort = f(R.id.etPort)
        etUser = f(R.id.etUser); etPass = f(R.id.etPass); cbTls = f(R.id.cbTls)
        etSni = f(R.id.etSni); etPayload = f(R.id.etPayload); etWsPath = f(R.id.etWsPath)
        etWsHost = f(R.id.etWsHost); etDnsResolver = f(R.id.etDnsResolver)
        etDnsDomain = f(R.id.etDnsDomain); etDnsKey = f(R.id.etDnsKey); etLink = f(R.id.etLink)
        btn = f(R.id.btnConnect); tvStatus = f(R.id.tvStatus); tvLog = f(R.id.tvLog)

        sp.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, Mode.values().map { it.label })
        sp.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: AdapterView<*>?, view: View?, pos: Int, id: Long) {
                applyMode(Mode.values()[pos])
            }
            override fun onNothingSelected(parent: AdapterView<*>?) {}
        }
        fill(Store.load(this))

        f<Button>(R.id.btnPaste).setOnClickListener {
            val cm = getSystemService(ClipboardManager::class.java)
            val t = cm.primaryClip?.getItemAt(0)?.text?.toString()?.trim().orEmpty()
            if (t.startsWith("vless://") || t.startsWith("vmess://") || t.startsWith("trojan://")) {
                etLink.setText(t)
            } else {
                Toast.makeText(this, "Clipboard has no vless/vmess/trojan link", Toast.LENGTH_SHORT).show()
            }
        }

        btn.setOnClickListener {
            if (Bus.state != State.IDLE) {
                startService(Intent(this, IsileVpnService::class.java).setAction(IsileVpnService.ACTION_STOP))
                return@setOnClickListener
            }
            val p = form()
            Store.save(this, p)
            val err = validate(p)
            if (err != null) {
                Toast.makeText(this, err, Toast.LENGTH_LONG).show()
                return@setOnClickListener
            }
            if (Build.VERSION.SDK_INT >= 33 &&
                checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
            ) notifPerm.launch(Manifest.permission.POST_NOTIFICATIONS)
            val i = VpnService.prepare(this)
            if (i != null) vpnPrompt.launch(i) else startVpn()
        }
    }

    override fun onResume() {
        super.onResume()
        Bus.listener = { runOnUiThread { refresh() } }
        refresh()
    }

    override fun onPause() {
        Bus.listener = null
        super.onPause()
    }

    private fun startVpn() {
        ContextCompat.startForegroundService(
            this, Intent(this, IsileVpnService::class.java).setAction(IsileVpnService.ACTION_START)
        )
    }

    private fun refresh() {
        tvStatus.text = when (Bus.state) {
            State.IDLE -> "Disconnected"
            State.CONNECTING -> "Connecting..."
            State.CONNECTED -> "Connected"
        }
        btn.text = if (Bus.state == State.IDLE) "Connect" else "Disconnect"
        tvLog.text = Bus.text()
    }

    private fun show(id: Int, on: Boolean) { f<View>(id).visibility = if (on) View.VISIBLE else View.GONE }

    private fun applyMode(m: Mode) {
        show(R.id.gHost, m.isSsh)
        show(R.id.gUser, m.isSsh || m == Mode.SLOWDNS)
        show(R.id.gTls, m == Mode.SSH_PAYLOAD || m == Mode.SSH_WS)
        show(R.id.gSni, m == Mode.SSH_PAYLOAD || m == Mode.SSH_WS || m == Mode.SSH_SSL)
        show(R.id.gPayload, m == Mode.SSH_PAYLOAD)
        show(R.id.gWs, m == Mode.SSH_WS)
        show(R.id.gDns, m == Mode.SLOWDNS)
        show(R.id.gLink, m == Mode.LINK)
    }

    private fun fill(p: Profile) {
        sp.setSelection(p.mode.ordinal)
        etHost.setText(p.host); etPort.setText(p.port.toString())
        etUser.setText(p.user); etPass.setText(p.pass)
        cbTls.isChecked = p.tls; etSni.setText(p.sni); etPayload.setText(p.payload)
        etWsPath.setText(p.wsPath); etWsHost.setText(p.wsHost)
        etDnsResolver.setText(p.dnsResolver); etDnsDomain.setText(p.dnsDomain)
        etDnsKey.setText(p.dnsPubKey); etLink.setText(p.link)
        applyMode(p.mode)
    }

    private fun form() = Profile(
        mode = Mode.values()[sp.selectedItemPosition],
        host = etHost.text.toString().trim(),
        port = etPort.text.toString().trim().toIntOrNull() ?: 22,
        user = etUser.text.toString().trim(),
        pass = etPass.text.toString(),
        tls = cbTls.isChecked,
        sni = etSni.text.toString().trim(),
        payload = etPayload.text.toString(),
        wsPath = etWsPath.text.toString().trim(),
        wsHost = etWsHost.text.toString().trim(),
        dnsResolver = etDnsResolver.text.toString().trim(),
        dnsDomain = etDnsDomain.text.toString().trim(),
        dnsPubKey = etDnsKey.text.toString().trim(),
        link = etLink.text.toString().trim()
    )

    private fun validate(p: Profile): String? = when {
        p.mode.isSsh && (p.host.isEmpty() || p.user.isEmpty() || p.pass.isEmpty()) -> "Fill host, username and password"
        p.mode == Mode.SLOWDNS && (p.user.isEmpty() || p.pass.isEmpty() || p.dnsDomain.isEmpty() || p.dnsPubKey.isEmpty()) ->
            "Fill username, password, domain and public key"
        p.mode == Mode.LINK && p.link.isEmpty() -> "Paste a vless/vmess/trojan link"
        else -> null
    }
}
