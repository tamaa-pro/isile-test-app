package com.tamaa.isilevpn

import android.content.Context
import android.graphics.Canvas
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.Shader
import android.util.AttributeSet
import android.view.View
import androidx.core.content.ContextCompat

/** منحنى سرعة متغير: التنزيل والرفع (آخر 60 ثانية). */
class SpeedGraph @JvmOverloads constructor(c: Context, a: AttributeSet? = null) : View(c, a) {
    private var down = LongArray(0)
    private var up = LongArray(0)
    private val cDown = ContextCompat.getColor(c, R.color.green)
    private val cUp = ContextCompat.getColor(c, R.color.purple)
    private val grid = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = ContextCompat.getColor(c, R.color.outline); strokeWidth = 1f
    }
    private val line = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE; strokeWidth = 3.5f; strokeCap = Paint.Cap.ROUND; strokeJoin = Paint.Join.ROUND
    }
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }

    fun set(d: LongArray, u: LongArray) {
        down = d; up = u
        invalidate()
    }

    override fun onDraw(cv: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        for (i in 1..3) cv.drawLine(0f, h * i / 4f, w, h * i / 4f, grid)
        val peak = maxOf(down.maxOrNull() ?: 0L, up.maxOrNull() ?: 0L)
        val max = maxOf(64 * 1024L, peak) * 1.15f
        draw(cv, up, max, cUp, w, h)
        draw(cv, down, max, cDown, w, h)
    }

    private fun draw(cv: Canvas, v: LongArray, max: Float, color: Int, w: Float, h: Float) {
        if (v.size < 2) return
        val pad = 6f
        val step = w / (Bus.POINTS - 1)
        val xs = FloatArray(v.size) { w - (v.size - 1 - it) * step }
        val ys = FloatArray(v.size) { h - pad - (v[it] / max) * (h - 2 * pad) }
        val path = Path()
        path.moveTo(xs[0], ys[0])
        for (i in 1 until v.size) {
            val mx = (xs[i - 1] + xs[i]) / 2f
            path.cubicTo(mx, ys[i - 1], mx, ys[i], xs[i], ys[i])
        }
        val area = Path(path)
        area.lineTo(xs[v.size - 1], h)
        area.lineTo(xs[0], h)
        area.close()
        fill.shader = LinearGradient(0f, 0f, 0f, h, (color and 0x00FFFFFF) or 0x55000000, color and 0x00FFFFFF, Shader.TileMode.CLAMP)
        cv.drawPath(area, fill)
        line.color = color
        cv.drawPath(path, line)
    }
}
