package com.tamaa.isilevpn

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import org.json.JSONObject
import java.io.IOException
import java.net.HttpURLConnection
import java.net.InetSocketAddress
import java.net.Proxy
import java.net.URL
import kotlin.math.cos
import kotlin.math.floor
import kotlin.math.ln
import kotlin.math.tan

data class IpData(
    val ip: String,
    val countryCode: String,
    val country: String,
    val continent: String,
    val region: String,
    val city: String,
    val postal: String,
    val lat: Double?,
    val lon: Double?,
    val asn: String,
    val org: String,
    val isp: String,
    val domain: String,
    val timezone: String,
    val currency: String,
    val callingCode: String,
    val extra: List<Pair<String, String>>
)

/** جلب معلومات الـ IP والخريطة والعلم. أثناء الاتصال تمر الطلبات عبر نفق SOCKS (لأن التطبيق مستثنى من الـ VPN). */
object IpInfo {
    private const val UA = "IsileVPN/1.0 (Android)"

    private fun open(url: String, viaProxy: Boolean): HttpURLConnection {
        val px = if (viaProxy) Proxy(Proxy.Type.SOCKS, InetSocketAddress("127.0.0.1", XrayConfig.SOCKS_PORT))
        else Proxy.NO_PROXY
        val c = URL(url).openConnection(px) as HttpURLConnection
        c.connectTimeout = 10000
        c.readTimeout = 10000
        c.setRequestProperty("User-Agent", UA)
        return c
    }

    fun getBytes(url: String, viaProxy: Boolean): ByteArray {
        val c = open(url, viaProxy)
        try {
            if (c.responseCode !in 200..299) throw IOException("HTTP ${c.responseCode}")
            return c.inputStream.use { it.readBytes() }
        } finally {
            c.disconnect()
        }
    }

    private fun s(o: JSONObject?, k: String): String =
        if (o == null || o.isNull(k)) "" else o.optString(k).trim()

    private fun d(o: JSONObject?, k: String): Double? =
        if (o == null || o.isNull(k)) null else o.optDouble(k).takeIf { !it.isNaN() }

    fun fetch(viaProxy: Boolean): IpData {
        var last: Exception? = null
        val attempts = if (viaProxy) 3 else 1
        for (i in 0 until attempts) {
            for (src in listOf({ v: Boolean -> fromIpWho(v) }, { v: Boolean -> fromIpApi(v) })) {
                try {
                    return src(viaProxy)
                } catch (e: Exception) {
                    last = e
                }
            }
            if (i < attempts - 1) try { Thread.sleep(2000) } catch (_: InterruptedException) { break }
        }
        throw last ?: IOException("Failed to get IP info")
    }

    private fun fromIpWho(via: Boolean): IpData {
        val j = JSONObject(String(getBytes("https://ipwho.is/", via)))
        if (!j.optBoolean("success", false)) throw IOException(s(j, "message").ifEmpty { "ipwho.is failed" })
        val conn = j.optJSONObject("connection")
        val tz = j.optJSONObject("timezone")
        val asnNum = conn?.optLong("asn", 0L) ?: 0L
        val extra = ArrayList<Pair<String, String>>()
        if (s(j, "capital").isNotEmpty()) extra.add("Capital" to s(j, "capital"))
        if (j.has("is_eu")) extra.add("EU member" to if (j.optBoolean("is_eu")) "Yes" else "No")
        if (s(j, "type").isNotEmpty()) extra.add("IP type" to s(j, "type"))
        val cur = j.optJSONObject("currency")
        val curStr = if (cur != null) listOf(s(cur, "name"), s(cur, "code")).filter { it.isNotEmpty() }.joinToString(" · ") else ""
        val utc = s(tz, "utc")
        return IpData(
            ip = s(j, "ip"),
            countryCode = s(j, "country_code"),
            country = s(j, "country"),
            continent = s(j, "continent"),
            region = s(j, "region"),
            city = s(j, "city"),
            postal = s(j, "postal"),
            lat = d(j, "latitude"), lon = d(j, "longitude"),
            asn = if (asnNum > 0) "AS$asnNum" else "",
            org = s(conn, "org"),
            isp = s(conn, "isp"),
            domain = s(conn, "domain"),
            timezone = s(tz, "id").let { id -> if (id.isNotEmpty() && utc.isNotEmpty()) "$id (UTC$utc)" else id.ifEmpty { utc } },
            currency = curStr,
            callingCode = s(j, "calling_code").let { if (it.isNotEmpty()) "+$it" else "" },
            extra = extra
        )
    }

    private fun fromIpApi(via: Boolean): IpData {
        val f = "status,message,continent,country,countryCode,regionName,city,zip,lat,lon,timezone,currency,isp,org,as,asname,reverse,mobile,proxy,hosting,query"
        val j = JSONObject(String(getBytes("http://ip-api.com/json/?fields=$f", via)))
        if (s(j, "status") != "success") throw IOException(s(j, "message").ifEmpty { "ip-api failed" })
        val extra = ArrayList<Pair<String, String>>()
        fun yn(k: String, label: String) { if (j.has(k)) extra.add(label to if (j.optBoolean(k)) "Yes" else "No") }
        yn("mobile", "Mobile network"); yn("proxy", "Proxy / VPN"); yn("hosting", "Hosting / datacenter")
        val asField = s(j, "as")
        return IpData(
            ip = s(j, "query"),
            countryCode = s(j, "countryCode"),
            country = s(j, "country"),
            continent = s(j, "continent"),
            region = s(j, "regionName"),
            city = s(j, "city"),
            postal = s(j, "zip"),
            lat = d(j, "lat"), lon = d(j, "lon"),
            asn = asField.substringBefore(' '),
            org = s(j, "org").ifEmpty { s(j, "asname") },
            isp = s(j, "isp"),
            domain = s(j, "reverse"),
            timezone = s(j, "timezone"),
            currency = s(j, "currency"),
            callingCode = "",
            extra = extra
        )
    }

    fun flagBitmap(cc: String, via: Boolean): Bitmap? {
        if (cc.length != 2) return null
        val b = getBytes("https://flagcdn.com/w160/${cc.lowercase()}.png", via)
        return BitmapFactory.decodeByteArray(b, 0, b.size)
    }

    fun flagEmoji(cc: String): String {
        if (cc.length != 2) return "🌐"
        return cc.uppercase().map { String(Character.toChars(0x1F1E6 + (it - 'A'))) }.joinToString("")
    }
}

/** يرسم خريطة OpenStreetMap (٣×٣ بلاطات) حول الإحداثيات مع علامة الموقع، دون أي مكتبة خارجية. */
object MapRender {
    private const val Z = 8
    private const val T = 256

    fun render(lat: Double, lon: Double, via: Boolean, w: Int = 512, h: Int = 320): Bitmap? {
        val n = 1 shl Z
        val xf = (lon + 180.0) / 360.0 * n
        val lr = Math.toRadians(lat.coerceIn(-85.0, 85.0))
        val yf = (1.0 - ln(tan(lr) + 1.0 / cos(lr)) / Math.PI) / 2.0 * n
        val cx = floor(xf).toInt()
        val cy = floor(yf).toInt()
        val fx = ((xf - cx) * T).toInt()
        val fy = ((yf - cy) * T).toInt()

        val big = Bitmap.createBitmap(T * 3, T * 3, Bitmap.Config.ARGB_8888)
        val bc = Canvas(big)
        bc.drawColor(Color.parseColor("#1A2330"))
        var ok = 0
        val threads = ArrayList<Thread>()
        for (dx in -1..1) for (dy in -1..1) {
            val ty = cy + dy
            if (ty < 0 || ty >= n) continue
            val tx = Math.floorMod(cx + dx, n)
            val th = Thread {
                try {
                    val b = IpInfo.getBytes("https://tile.openstreetmap.org/$Z/$tx/$ty.png", via)
                    val bm = BitmapFactory.decodeByteArray(b, 0, b.size)
                    if (bm != null) synchronized(bc) {
                        bc.drawBitmap(bm, ((dx + 1) * T).toFloat(), ((dy + 1) * T).toFloat(), null)
                        ok++
                    }
                } catch (_: Exception) {
                }
            }
            th.isDaemon = true
            th.start()
            threads.add(th)
        }
        threads.forEach { try { it.join(15000) } catch (_: InterruptedException) {} }
        if (ok == 0) return null

        val out = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val c = Canvas(out)
        c.drawBitmap(big, (-(T + fx - w / 2)).toFloat(), (-(T + fy - h / 2)).toFloat(), null)

        val mx = w / 2f
        val my = h / 2f
        val p = Paint(Paint.ANTI_ALIAS_FLAG)
        p.color = Color.argb(60, 239, 68, 68); c.drawCircle(mx, my, 34f, p)
        p.color = Color.argb(110, 239, 68, 68); c.drawCircle(mx, my, 20f, p)
        p.color = Color.WHITE; c.drawCircle(mx, my, 11f, p)
        p.color = Color.parseColor("#EF4444"); c.drawCircle(mx, my, 8f, p)

        val txt = "© OpenStreetMap contributors"
        p.textSize = 11f
        val tw = p.measureText(txt)
        p.color = Color.argb(170, 255, 255, 255)
        c.drawRect(RectF(w - tw - 12f, h - 18f, w.toFloat(), h.toFloat()), p)
        p.color = Color.parseColor("#333333")
        c.drawText(txt, w - tw - 6f, h - 5f, p)
        return out
    }
}
