package com.tamaa.isilevpn

import android.content.Context
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import java.net.Inet4Address
import java.net.NetworkInterface

/**
 * عنوان IP الحقيقي للجهاز كما يعرفه النظام (واجهة الواي فاي / بيانات الهاتف)،
 * دون أي اتصال بالإنترنت، ويتجاهل واجهة الـ VPN. يعمل حتى لو لم تكن هناك باقة.
 */
object LocalIp {
    fun get(ctx: Context): String {
        try {
            val cm = ctx.getSystemService(ConnectivityManager::class.java)
            val active = cm.activeNetwork
            var best = ""
            var bestScore = -1
            @Suppress("DEPRECATION")
            for (n in cm.allNetworks) {
                val caps = cm.getNetworkCapabilities(n) ?: continue
                if (caps.hasTransport(NetworkCapabilities.TRANSPORT_VPN)) continue
                val lp = cm.getLinkProperties(n) ?: continue
                for (la in lp.linkAddresses) {
                    val a = la.address
                    if (a.isLoopbackAddress || a.isLinkLocalAddress || a.isAnyLocalAddress) continue
                    val h = a.hostAddress?.substringBefore('%') ?: continue
                    var score = if (a is Inet4Address) 10 else 0
                    if (n == active) score += 5
                    if (caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_VALIDATED)) score += 3
                    if (score > bestScore) { bestScore = score; best = h }
                }
            }
            if (best.isNotEmpty()) return best
        } catch (_: Exception) {
        }
        // احتياط: قراءة واجهات الشبكة مباشرة
        try {
            val ifs = NetworkInterface.getNetworkInterfaces() ?: return ""
            for (ni in ifs) {
                if (!ni.isUp || ni.isLoopback || ni.name.startsWith("tun") || ni.name.startsWith("dummy")) continue
                for (a in ni.inetAddresses) {
                    if (a is Inet4Address && !a.isLoopbackAddress && !a.isLinkLocalAddress) return a.hostAddress ?: continue
                }
            }
        } catch (_: Exception) {
        }
        return ""
    }
}
