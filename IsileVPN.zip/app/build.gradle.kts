plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.tamaa.isilevpn"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.tamaa.isilevpn"
        minSdk = 24
        targetSdk = 34
        // يزداد تلقائيًا (دقائق منذ 1970) فيكون كل بناء أحدث من السابق دائمًا
        versionCode = (System.currentTimeMillis() / 60000L).toInt()
        versionName = "0.3.2"
        ndk { abiFilters += listOf("arm64-v8a") }
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            // التوقيع الافتراضي (debug keystore) ليكون APK الـ release قابلاً للتثبيت مباشرة
            signingConfig = signingConfigs.getByName("debug")
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }

    // مهم: يجب استخراج المكتبات لتشغيل xray و dnstt كعمليات (executables)
    packaging { jniLibs { useLegacyPackaging = true } }

    lint {
        abortOnError = false
        checkReleaseBuilds = false
    }
}

dependencies {
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.appcompat:appcompat:1.7.0")
    implementation("androidx.drawerlayout:drawerlayout:1.2.0")
    implementation("androidx.viewpager:viewpager:1.0.0")
    implementation("com.google.android.material:material:1.12.0")
    implementation("com.github.mwiede:jsch:0.2.20")
}
