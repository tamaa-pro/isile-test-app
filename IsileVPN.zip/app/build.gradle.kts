plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.tamaa.isilevpn"
    compileSdk = 34

    // توقيع ثابت ودائم: المفتاح وكلمة السر يأتيان من GitHub Secrets (لا يوجد شيء خاص في الكود)
    val ksFile = file("isile-release.jks")
    val ksPass = System.getenv("KEYSTORE_PASSWORD")
    val hasKeystore = ksFile.exists() && !ksPass.isNullOrEmpty()
    signingConfigs {
        if (hasKeystore) {
            create("isile") {
                storeFile = ksFile
                storePassword = ksPass
                keyAlias = "isile"
                keyPassword = ksPass
            }
        }
    }
    val appSigning = if (hasKeystore) signingConfigs.getByName("isile") else signingConfigs.getByName("debug")

    defaultConfig {
        applicationId = "com.tamaa.isilevpn"
        minSdk = 24
        targetSdk = 34
        // يزداد تلقائيًا (دقائق منذ 1970) فيكون كل بناء أحدث من السابق دائمًا
        versionCode = (System.currentTimeMillis() / 60000L).toInt()
        versionName = "0.3.4"
        ndk { abiFilters += listOf("arm64-v8a") }
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            signingConfig = appSigning
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }

    // مهم: يجب استخراج المكتبات لتشغيل xray و dnstt كعمليات (executables)
    packaging { jniLibs { useLegacyPackaging = true } }

    lint {
        abortOnError = false
        checkReleaseBuilds = false
    }
}

dependencies {
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.appcompat:appcompat:1.7.0")
    implementation("androidx.drawerlayout:drawerlayout:1.2.0")
    implementation("androidx.viewpager:viewpager:1.0.0")
    implementation("com.google.android.material:material:1.12.0")
    implementation("com.github.mwiede:jsch:0.2.20")
}
