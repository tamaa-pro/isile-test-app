package com.example.dashboards

import android.app.Activity
import android.app.AlertDialog
import android.app.Dialog
import android.content.Context
import android.content.res.ColorStateList
import android.graphics.*
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.RippleDrawable
import android.net.Uri
import android.os.Bundle
import android.text.InputType
import android.util.TypedValue
import android.view.*
import android.view.ViewGroup.LayoutParams.MATCH_PARENT
import android.view.ViewGroup.LayoutParams.WRAP_CONTENT
import android.webkit.*
import android.widget.*
import org.json.JSONArray
import org.json.JSONObject

class IconView(c: Context, private val kind: String, col: Int) : View(c) {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = col; style = Paint.Style.STROKE; strokeWidth = 1.9f
        strokeCap = Paint.Cap.ROUND; strokeJoin = Paint.Join.ROUND
    }
    override fun onDraw(c: Canvas) {
        val w = width - paddingLeft - paddingRight
        val h = height - paddingTop - paddingBottom
        val s = minOf(w, h) / 24f
        c.translate(paddingLeft + (w - 24 * s) / 2, paddingTop + (h - 24 * s) / 2)
        c.scale(s, s)
        fun l(a: Float, b: Float, x: Float, y: Float) = c.drawLine(a, b, x, y, p)
        when (kind) {
            "plus" -> { l(12f, 5f, 12f, 19f); l(5f, 12f, 19f, 12f) }
            "menu" -> { l(5f, 7f, 19f, 7f); l(5f, 12f, 19f, 12f); l(5f, 17f, 19f, 17f) }
            "edit" -> { l(6f, 18f, 17f, 7f); l(15f, 5f, 19f, 9f); l(5f, 20f, 10f, 20f) }
            "trash" -> { l(5f, 7f, 19f, 7f); l(10f, 4f, 14f, 4f); l(7f, 7f, 8f, 19f)
                l(17f, 7f, 16f, 19f); l(8f, 19f, 16f, 19f) }
        }
    }
}

class MainActivity : Activity() {

    class Page(var name: String, var url: String, var desktop: Boolean = false)

    private val BG = Color.parseColor("#0F1115")
    private val BAR = Color.parseColor("#171A21")
    private val SHEET = Color.parseColor("#1C2028")
    private val FIELD = Color.parseColor("#262B35")
    private val TXT = Color.parseColor("#ECEFF4")
    private val SUB = Color.parseColor("#8B93A1")
    private val ACCENT = Color.parseColor("#7AA2F7")
    private val DANGER = Color.parseColor("#F7768E")
    private val palette = intArrayOf(0xFF7AA2F7.toInt(), 0xFFBB9AF7.toInt(), 0xFF9ECE6A.toInt(),
        0xFFE0AF68.toInt(), 0xFF2AC3DE.toInt(), 0xFFF7768E.toInt())

    private val DESKTOP_UA = "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36"
    private val VIEWPORT_JS = "(function(){var m=document.querySelector('meta[name=viewport]');if(!m){m=document.createElement('meta');m.name='viewport';(document.head||document.documentElement).appendChild(m)}m.setAttribute('content','width=1280')})()"

    private val pages = mutableListOf<Page>()
    private var current = -1
    private lateinit var web: WebView
    private lateinit var titleView: TextView
    private lateinit var subView: TextView
    private lateinit var progress: ProgressBar
    private lateinit var empty: View
    private lateinit var mobileUA: String

    private fun dp(v: Int) = TypedValue.applyDimension(
        TypedValue.COMPLEX_UNIT_DIP, v.toFloat(), resources.displayMetrics).toInt()

    private fun rounded(c: Int, r: Int, top: Boolean = false) = GradientDrawable().apply {
        setColor(c)
        val x = dp(r).toFloat()
        cornerRadii = if (top) floatArrayOf(x, x, x, x, 0f, 0f, 0f, 0f) else FloatArray(8) { x }
    }

    private fun label(t: String, size: Float, col: Int, bold: Boolean) = TextView(this).apply {
        text = t; textSize = size; setTextColor(col)
        if (bold) typeface = Typeface.DEFAULT_BOLD
    }

    private fun icon(kind: String, col: Int, size: Int = 40, pad: Int = 10, click: () -> Unit) =
        IconView(this, kind, col).apply {
            setPadding(dp(pad), dp(pad), dp(pad), dp(pad))
            background = RippleDrawable(ColorStateList.valueOf(0x33FFFFFF), null,
                GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(Color.WHITE) })
            layoutParams = LinearLayout.LayoutParams(dp(size), dp(size))
            setOnClickListener { click() }
        }

    private fun filled(t: String, click: () -> Unit) = TextView(this).apply {
        text = t; textSize = 15f; setTextColor(BG); typeface = Typeface.DEFAULT_BOLD
        gravity = Gravity.CENTER; setPadding(dp(16), dp(14), dp(16), dp(14))
        background = rounded(ACCENT, 14); setOnClickListener { click() }
    }

    private fun add(box: LinearLayout, v: View, top: Int = 0) =
        box.addView(v, LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT).apply { topMargin = dp(top) })

    private fun host(u: String) = Uri.parse(u).host ?: u

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = BAR
        window.navigationBarColor = BG
        load()

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(BG)
            layoutDirection = View.LAYOUT_DIRECTION_LTR
            setOnApplyWindowInsetsListener { v, i ->
                @Suppress("DEPRECATION")
                v.setPadding(0, i.systemWindowInsetTop, 0, i.systemWindowInsetBottom); i
            }
        }

        val bar = FrameLayout(this).apply { setBackgroundColor(BAR) }
        val titles = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER }
        titleView = label("لوحاتي", 15f, TXT, true).apply {
            maxLines = 1; ellipsize = android.text.TextUtils.TruncateAt.END
        }
        subView = label("", 10f, SUB, false).apply {
            maxLines = 1; ellipsize = android.text.TextUtils.TruncateAt.END
        }
        titles.addView(titleView); titles.addView(subView)
        bar.addView(titles, FrameLayout.LayoutParams(MATCH_PARENT, MATCH_PARENT)
            .apply { setMargins(dp(64), 0, dp(64), 0) })
        bar.addView(icon("plus", ACCENT, 44, 11) { showForm(null) },
            FrameLayout.LayoutParams(dp(44), dp(44), Gravity.LEFT or Gravity.CENTER_VERTICAL).apply { leftMargin = dp(8) })
        bar.addView(icon("menu", TXT, 44, 11) { showList() },
            FrameLayout.LayoutParams(dp(44), dp(44), Gravity.RIGHT or Gravity.CENTER_VERTICAL).apply { rightMargin = dp(8) })
        root.addView(bar, LinearLayout.LayoutParams(MATCH_PARENT, dp(48)))

        progress = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply {
            max = 100
            progressTintList = ColorStateList.valueOf(ACCENT)
            progressBackgroundTintList = ColorStateList.valueOf(Color.parseColor("#262B35"))
        }
        root.addView(progress, LinearLayout.LayoutParams(MATCH_PARENT, dp(2)))

        val content = FrameLayout(this)
        web = WebView(this).apply {
            setBackgroundColor(BG)
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            settings.useWideViewPort = true
            settings.setSupportZoom(true)
            settings.builtInZoomControls = true
            settings.displayZoomControls = false
            if (android.os.Build.VERSION.SDK_INT >= 33) settings.isAlgorithmicDarkeningAllowed = true
            webChromeClient = object : WebChromeClient() {
                override fun onProgressChanged(v: WebView, p: Int) { progress.progress = if (p >= 100) 0 else p }
            }
            webViewClient = object : WebViewClient() {
                private fun fix(v: WebView) {
                    if (pages.getOrNull(current)?.desktop == true) v.evaluateJavascript(VIEWPORT_JS, null)
                }
                override fun onPageCommitVisible(v: WebView, u: String) = fix(v)
                override fun onPageFinished(v: WebView, u: String) = fix(v)
            }
        }
        mobileUA = web.settings.userAgentString
        content.addView(web, FrameLayout.LayoutParams(MATCH_PARENT, MATCH_PARENT))

        val emptyBox = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER
            setBackgroundColor(BG); setPadding(dp(40), 0, dp(40), 0)
            addView(label("لا توجد لوحات بعد", 17f, TXT, true))
            addView(label("أضف رابط لوحة التحكم لتبدأ", 13f, SUB, false).apply { setPadding(0, dp(6), 0, dp(20)) })
            addView(filled("إضافة لوحة") { showForm(null) })
        }
        empty = emptyBox
        content.addView(emptyBox, FrameLayout.LayoutParams(MATCH_PARENT, MATCH_PARENT))
        root.addView(content, LinearLayout.LayoutParams(MATCH_PARENT, 0, 1f))
        setContentView(root)

        open(prefs().getInt("current", 0))
    }

    private fun open(i: Int) {
        if (i !in pages.indices) {
            current = -1; titleView.text = "لوحاتي"; subView.text = ""
            web.loadUrl("about:blank"); empty.visibility = View.VISIBLE; return
        }
        empty.visibility = View.GONE
        current = i
        val p = pages[i]
        titleView.text = p.name
        subView.text = host(p.url) + if (p.desktop) "  ·  سطح المكتب" else ""
        web.settings.userAgentString = if (p.desktop) DESKTOP_UA else mobileUA
        web.settings.loadWithOverviewMode = p.desktop
        web.setInitialScale(0)
        web.loadUrl(p.url)
        prefs().edit().putInt("current", i).apply()
    }

    private fun sheetBox() = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        background = rounded(SHEET, 24, true)
        setPadding(dp(20), dp(20), dp(20), dp(20))
        layoutDirection = View.LAYOUT_DIRECTION_RTL
    }

    private fun sheet(content: View): Dialog {
        val d = Dialog(this)
        d.requestWindowFeature(Window.FEATURE_NO_TITLE)
        d.setContentView(content)
        d.window?.apply {
            setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
            setLayout(MATCH_PARENT, WRAP_CONTENT)
            setGravity(Gravity.BOTTOM)
            setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE)
        }
        return d
    }

    private fun field(hint: String, value: String) = EditText(this).apply {
        this.hint = hint; setText(value); setSingleLine()
        setTextColor(TXT); setHintTextColor(SUB); textSize = 15f
        background = rounded(FIELD, 14); setPadding(dp(16), dp(14), dp(16), dp(14))
    }

    private fun showForm(edit: Page?) {
        val box = sheetBox()
        add(box, label(if (edit == null) "إضافة لوحة" else "تعديل اللوحة", 18f, TXT, true))
        val name = field("اسم اللوحة", edit?.name ?: "")
        val url = field("الرابط  https://", edit?.url ?: "").apply {
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_URI
            textDirection = View.TEXT_DIRECTION_LTR
        }
        add(box, name, 16); add(box, url, 10)
        val sw = Switch(this).apply { isChecked = edit?.desktop ?: false }
        val row = LinearLayout(this).apply {
            gravity = Gravity.CENTER_VERTICAL; setPadding(dp(4), dp(8), dp(4), dp(8))
            addView(LinearLayout(context).apply {
                orientation = LinearLayout.VERTICAL
                addView(label("وضع سطح المكتب", 15f, TXT, false))
                addView(label("عرض الصفحة بعرض 1280 بدل عرض الهاتف", 11f, SUB, false))
            }, LinearLayout.LayoutParams(0, WRAP_CONTENT, 1f))
            addView(sw)
        }
        add(box, row, 10)
        val dlg = sheet(box)
        add(box, filled("حفظ") {
            var u = url.text.toString().trim()
            if (u.isEmpty()) return@filled
            if (!u.contains("://")) u = "https://$u"
            val n = name.text.toString().trim().ifEmpty { host(u) }
            if (edit == null) { pages.add(Page(n, u, sw.isChecked)); save(); open(pages.size - 1) }
            else { edit.name = n; edit.url = u; edit.desktop = sw.isChecked; save(); open(pages.indexOf(edit)) }
            dlg.dismiss()
        }, 12)
        dlg.show()
    }

    private fun showList() {
        val box = sheetBox()
        add(box, label("اللوحات", 18f, TXT, true))
        val list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        add(box, ScrollView(this).apply { addView(list) }, 10)
        val dlg = sheet(box)

        if (pages.isEmpty()) add(list, label("لا توجد لوحات محفوظة", 14f, SUB, false)
            .apply { setPadding(dp(4), dp(12), dp(4), dp(12)) })

        pages.toList().forEachIndexed { i, p ->
            val row = LinearLayout(this).apply {
                gravity = Gravity.CENTER_VERTICAL
                setPadding(dp(10), dp(8), dp(6), dp(8))
                if (i == current) background = rounded(0x227AA2F7, 14)
                setOnClickListener { dlg.dismiss(); open(i) }
            }
            row.addView(TextView(this).apply {
                text = p.name.take(1).uppercase(); gravity = Gravity.CENTER
                setTextColor(BG); textSize = 16f; typeface = Typeface.DEFAULT_BOLD
                background = GradientDrawable().apply {
                    shape = GradientDrawable.OVAL
                    setColor(palette[Math.abs(p.name.hashCode()) % palette.size])
                }
            }, LinearLayout.LayoutParams(dp(40), dp(40)))
            row.addView(LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                addView(label(p.name, 15f, if (i == current) ACCENT else TXT, true).apply { maxLines = 1 })
                addView(label(host(p.url) + if (p.desktop) " · سطح المكتب" else "", 11f, SUB, false).apply { maxLines = 1 })
            }, LinearLayout.LayoutParams(0, WRAP_CONTENT, 1f).apply { marginStart = dp(12); marginEnd = dp(6) })
            row.addView(icon("edit", SUB) { dlg.dismiss(); showForm(p) })
            row.addView(icon("trash", DANGER) {
                AlertDialog.Builder(this, AlertDialog.THEME_DEVICE_DEFAULT_DARK)
                    .setMessage("حذف «${p.name}»؟")
                    .setPositiveButton("حذف") { _, _ ->
                        dlg.dismiss()
                        pages.remove(p); save()
                        if (i == current) open(0) else if (i < current) current -= 1
                        showList()
                    }.setNegativeButton("إلغاء", null).show()
            })
            add(list, row, 4)
        }
        add(box, filled("إضافة لوحة") { dlg.dismiss(); showForm(null) }, 12)
        dlg.show()
    }

    private fun prefs() = getSharedPreferences("dash", Context.MODE_PRIVATE)

    private fun save() {
        val arr = JSONArray()
        pages.forEach { arr.put(JSONObject().put("n", it.name).put("u", it.url).put("d", it.desktop)) }
        prefs().edit().putString("pages", arr.toString()).apply()
    }

    private fun load() {
        val s = prefs().getString("pages", null) ?: return
        val arr = JSONArray(s)
        for (i in 0 until arr.length()) {
            val o = arr.getJSONObject(i)
            pages.add(Page(o.getString("n"), o.getString("u"), o.optBoolean("d", false)))
        }
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        if (web.canGoBack()) web.goBack() else super.onBackPressed()
    }
}
