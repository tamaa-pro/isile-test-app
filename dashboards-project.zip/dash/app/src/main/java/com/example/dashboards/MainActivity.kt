package com.example.dashboards   // غيّر هذا السطر ليطابق اسم الحزمة في مشروعك

import android.app.Activity
import android.app.AlertDialog
import android.content.Context
import android.graphics.Color
import android.graphics.Typeface
import android.os.Build
import android.os.Bundle
import android.text.InputType
import android.util.TypedValue
import android.view.Gravity
import android.view.View
import android.view.ViewGroup.LayoutParams.MATCH_PARENT
import android.view.ViewGroup.LayoutParams.WRAP_CONTENT
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.*
import org.json.JSONArray
import org.json.JSONObject

class MainActivity : Activity() {

    class Page(var name: String, var url: String)

    private val BG = Color.parseColor("#121212")
    private val BAR = Color.parseColor("#1E1E1E")
    private val TXT = Color.parseColor("#EEEEEE")
    private val ACCENT = Color.parseColor("#8AB4F8")

    private val pages = mutableListOf<Page>()
    private var current = -1
    private lateinit var web: WebView
    private lateinit var titleView: TextView

    private fun dp(v: Int) = TypedValue.applyDimension(
        TypedValue.COMPLEX_UNIT_DIP, v.toFloat(), resources.displayMetrics).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = BAR
        window.navigationBarColor = BG
        load()

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(BG)
            layoutDirection = View.LAYOUT_DIRECTION_LTR   // يبقى + يسارًا والقائمة يمينًا
            setOnApplyWindowInsetsListener { v, i ->
                @Suppress("DEPRECATION")
                v.setPadding(0, i.systemWindowInsetTop, 0, i.systemWindowInsetBottom); i
            }
        }

        // الشريط العلوي
        val bar = FrameLayout(this).apply { setBackgroundColor(BAR) }
        titleView = TextView(this).apply {
            setTextColor(TXT); textSize = 15f; typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER; maxLines = 1
            ellipsize = android.text.TextUtils.TruncateAt.END
        }
        bar.addView(titleView, FrameLayout.LayoutParams(MATCH_PARENT, MATCH_PARENT)
            .apply { setMargins(dp(56), 0, dp(56), 0) })
        bar.addView(iconBtn("+") { showForm(null) },
            FrameLayout.LayoutParams(dp(52), MATCH_PARENT, Gravity.LEFT))
        bar.addView(iconBtn("☰") { showList() },
            FrameLayout.LayoutParams(dp(52), MATCH_PARENT, Gravity.RIGHT))
        root.addView(bar, LinearLayout.LayoutParams(MATCH_PARENT, dp(44)))

        // واجهة الويب
        web = WebView(this).apply {
            setBackgroundColor(BG)
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            if (Build.VERSION.SDK_INT >= 33) settings.isAlgorithmicDarkeningAllowed = true
            webViewClient = WebViewClient()
        }
        root.addView(web, LinearLayout.LayoutParams(MATCH_PARENT, 0, 1f))
        setContentView(root)

        open(prefs().getInt("current", 0))
    }

    private fun iconBtn(t: String, click: () -> Unit) = TextView(this).apply {
        text = t; setTextColor(ACCENT); textSize = 24f; gravity = Gravity.CENTER
        setOnClickListener { click() }
    }

    // ---------- فتح صفحة ----------
    private fun open(i: Int) {
        if (i !in pages.indices) {
            current = -1; titleView.text = "لا توجد صفحة"; web.loadUrl("about:blank"); return
        }
        current = i
        titleView.text = pages[i].name
        web.loadUrl(pages[i].url)
        prefs().edit().putInt("current", i).apply()
    }

    // ---------- نافذة إضافة / تعديل ----------
    private fun showForm(edit: Page?) {
        val name = field("اسم الصفحة", edit?.name ?: "")
        val url = field("الرابط", edit?.url ?: "").apply {
            inputType = InputType.TYPE_TEXT_VARIATION_URI
        }
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(dp(20), dp(8), dp(20), 0)
            addView(name); addView(url)
        }
        AlertDialog.Builder(this, AlertDialog.THEME_DEVICE_DEFAULT_DARK)
            .setTitle(if (edit == null) "إضافة صفحة" else "تعديل الصفحة")
            .setView(box)
            .setPositiveButton("حفظ") { _, _ ->
                var u = url.text.toString().trim()
                val n = name.text.toString().trim().ifEmpty { u }
                if (u.isEmpty()) return@setPositiveButton
                if (!u.contains("://")) u = "https://$u"
                if (edit == null) { pages.add(Page(n, u)); save(); open(pages.size - 1) }
                else { edit.name = n; edit.url = u; save(); open(pages.indexOf(edit)) }
            }
            .setNegativeButton("إلغاء", null).show()
    }

    private fun field(hint: String, value: String) = EditText(this).apply {
        this.hint = hint; setText(value); setSingleLine()
    }

    // ---------- نافذة القائمة ----------
    private fun showList() {
        val list = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(dp(8), dp(8), dp(8), dp(8))
        }
        val scroll = ScrollView(this).apply { addView(list) }
        val dlg = AlertDialog.Builder(this, AlertDialog.THEME_DEVICE_DEFAULT_DARK)
            .setTitle("الصفحات المحفوظة").setView(scroll)
            .setNegativeButton("إغلاق", null).create()

        if (pages.isEmpty()) list.addView(TextView(this).apply {
            text = "لا توجد صفحات بعد"; setTextColor(TXT); setPadding(dp(12), dp(12), dp(12), dp(12))
        })
        pages.toList().forEachIndexed { i, p ->
            val row = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
            row.addView(TextView(this).apply {
                text = p.name; setTextColor(if (i == current) ACCENT else TXT); textSize = 16f
                setPadding(dp(12), dp(14), dp(12), dp(14)); maxLines = 1
                setOnClickListener { dlg.dismiss(); open(i) }
            }, LinearLayout.LayoutParams(0, WRAP_CONTENT, 1f))
            row.addView(iconBtn("✎") { dlg.dismiss(); showForm(p) }.apply { textSize = 20f },
                LinearLayout.LayoutParams(dp(44), dp(44)))
            row.addView(iconBtn("✕") {
                dlg.dismiss()
                val wasCurrent = pages.indexOf(p) == current
                pages.remove(p); save()
                open(if (wasCurrent) 0 else pages.indexOf(pages.getOrNull(current)).coerceAtLeast(0))
            }.apply { textSize = 20f; setTextColor(Color.parseColor("#F28B82")) },
                LinearLayout.LayoutParams(dp(44), dp(44)))
            list.addView(row)
        }
        dlg.show()
    }

    // ---------- التخزين ----------
    private fun prefs() = getSharedPreferences("dash", Context.MODE_PRIVATE)

    private fun save() {
        val arr = JSONArray()
        pages.forEach { arr.put(JSONObject().put("n", it.name).put("u", it.url)) }
        prefs().edit().putString("pages", arr.toString()).apply()
    }

    private fun load() {
        val s = prefs().getString("pages", null) ?: return
        val arr = JSONArray(s)
        for (i in 0 until arr.length()) {
            val o = arr.getJSONObject(i); pages.add(Page(o.getString("n"), o.getString("u")))
        }
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        if (web.canGoBack()) web.goBack() else super.onBackPressed()
    }
}
